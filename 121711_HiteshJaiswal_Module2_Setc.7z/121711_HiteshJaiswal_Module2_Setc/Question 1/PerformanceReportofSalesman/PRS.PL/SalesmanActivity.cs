﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PRS.Entity;
using PRS.Exception;
using PRS.DAL;
using PRS.BL;

namespace PRS.PL
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : SalesmanActivity class will deal with the Salesman Interaction
    /// Date of Creation : 
    /// </summary>
    public class SalesmanActivity
    {
      
        public static void AddSalesman()
        {
            Salesman slm = new Salesman();
            try
            {
                Console.Write("\nEnter Salesman Code : ");
                slm.SalesmanCode = Console.ReadLine();
                Console.Write("\nEnter Salesman Name : ");
                slm.Name = Console.ReadLine();
                Console.Write("\nEnter Salesman Zone : ");
                slm.Zone = Console.ReadLine();
                Console.Write("\nEnter Salesman Region : ");
                slm.Region = Console.ReadLine();
                Console.Write("\nEnter Date of Sale : ");
                slm.Date = Convert.ToDateTime(Console.ReadLine());
                Console.Write("\nEnter Product Code : ");
                slm.ProductCode = Console.ReadLine();
                Console.Write("\nEnter Target Set: ");
                slm.TargetSet = Convert.ToDouble(Console.ReadLine());
                Console.Write("\nEnter Actual Sales : ");
                slm.ActualSales = Convert.ToDouble(Console.ReadLine());
                Console.Write("\nEnter Remarks : ");
                slm.Remarks = Console.ReadLine();
                double Variation=slm.TargetSet - slm.ActualSales;
                Console.WriteLine("\nVariation: "+Variation);

                bool slmAdded = SalesmanValidation.AddSalesman(slm);

                if (slmAdded)
                {
                    Console.WriteLine("\nSalesman Details are added successfully");
                }
                else
                {
                    throw new SalesmanException("Salesman Details are not Added");
                }
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DisplayAllSalesman()
        {
            try
            {
                List<Salesman> slmList = SalesmanValidation.DisplayAllSalesman();

                if (slmList.Count > 0)
                {
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                    Console.WriteLine("Salesman Code     Name     Zone   Region    Date    Product Code     TargetSet       ActucalSales        Remarks");
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                    foreach (Salesman slm in slmList)
                    {
                        Console.WriteLine(slm.SalesmanCode + "\t" + slm.Name + "\t" + slm.Zone + "\t" + slm.Region + "\t" + slm.Date + "\t" + slm.ProductCode + "\t" + slm.TargetSet + "\t" + slm.ActualSales + "\t" + slm.Remarks);
                    }
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                }
                else
                {
                    throw new SalesmanException("Salesman List is Empty");
                }
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeSalesman()
        {
            try
            {
                bool slmSerialized = SalesmanValidation.SerializeSalesman();

                if (slmSerialized)
                {
                    Console.WriteLine("Salesman Data Serialized Successfully");
                }
                else
                {
                    throw new SalesmanException("Salesman Data is not Serialized");
                }
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeSalesman()
        {
            try
            {
                List<Salesman> slmList = SalesmanValidation.DeserializeSalesman();

                if (slmList.Count > 0)
                {
                    Console.WriteLine("\nSalesman data Deserialized Successfully");

                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                    Console.WriteLine("Salesman Code     Name     Zone   Region    Date    Product Code     TargetSet       ActucalSales        Remarks");
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                    foreach (Salesman slm in slmList)
                    {
                        Console.WriteLine(slm.SalesmanCode + "\t" + slm.Name + "\t" + slm.Zone + "\t" + slm.Region + "\t" + slm.Date + "\t" + slm.ProductCode + "\t" + slm.TargetSet + "\t" + slm.ActualSales + "\t" + slm.Remarks);
                    }
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------------------\n");
                }
                else
                {
                    throw new SalesmanException("Salesman Data is not Deserialized");
                }
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("\n-------Application for Performance Report Tracking of the Salesman----\n");
            Console.WriteLine("1. Add Salesman Details");
            Console.WriteLine("2. Display Salesman Details");
            Console.WriteLine("3. Serialize Salesman Details");
            Console.WriteLine("4. Deserialize Salesman Details");
            Console.WriteLine("5. Exit");
            Console.WriteLine("\n------------------------------------------------------------------------\n");
        }



        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("\nEnter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddSalesman();
                            break;
                        case 2: DisplayAllSalesman();
                            break;
                        case 3: SerializeSalesman();
                            break;
                        case 4: DeserializeSalesman();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("\nInvalid Choice");
                            break;
                    }
                } while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
