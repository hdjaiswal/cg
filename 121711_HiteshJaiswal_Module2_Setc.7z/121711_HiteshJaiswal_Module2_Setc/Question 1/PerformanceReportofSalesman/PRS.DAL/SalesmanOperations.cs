﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PRS.Entity;
using PRS.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PRS.DAL
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : SalesmanOperations class will deal with the Salesman data
    /// Date of Creation : 
    /// </summary>
    public class SalesmanOperations
    {
        static List<Salesman> slmList = new List<Salesman>();

       
        public static bool AddSalesman(Salesman slm)
        {
            bool slmAdded = false;

            try
            {
              
                slmList.Add(slm);
                slmAdded = true;
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmAdded;
        }

        public static List<Salesman> DisplayAllSalesman()
        {
            return slmList;
        }

         public static bool SerializeSalesman()
        {
            bool slmSerialized = false;

            try 
            {
                if (slmList.Count > 0)
                {
                    FileStream fs = new FileStream("Salesman.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, slmList);
                    fs.Close();
                    slmSerialized = true;
                }
                else
                {
                    throw new SalesmanException("No Salesman Data, so it cannot be serialize");
                }
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmSerialized;
        }

        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> desslmList = null;

            try 
            {
                FileStream fs = new FileStream("Salesman.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desslmList = (List<Salesman>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desslmList;
        }
    }
}


    