﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PRS.Entity;
using PRS.Exception;
using PRS.DAL;

namespace PRS.BL
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : SalesmanValidation class will deal with the validation of Salesman data
    /// Date of Creation : 
    /// </summary>
    /// 
    public class SalesmanValidation
    {
        public static bool ValidateSalesman(Salesman slm)
        {
            bool slmValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (slm.SalesmanCode == String.Empty)
                {
                    message.Append("Salesman Code should be Provided\n");
                    slmValidated = false;
                }
                else if (!Regex.IsMatch(slm.SalesmanCode, "[1][0-9]{3}"))
                {
                    message.Append("Salesman Code have to start with 1 and should be 4 digit only");
                    slmValidated = false;
                }

                if (slm.Date == null)
                {
                    message.Append("Date should be provided\n");
                    slmValidated = false;
                }
                else if (slm.Date > DateTime.Today)
                {
                    message.Append("Date of Joining should be less than or equal to current date\n");
                    slmValidated = false;
                }

                 if (slm.Region.ToLower() != "north" && slm.Region.ToLower() != "west" && slm.Region.ToLower() != "east" && slm.Region!="south")
                {
                    message.Append("Region should be either West or North or East or South\n");
                    slmValidated = false;
                }

                 if (slm.Zone.ToLower() != "indian" && slm.Zone.ToLower() != "pacific")
                 {
                     message.Append("Zone should be either Indian or Pacific\n");
                     slmValidated = false;
                 }

                if (slmValidated == false)
                {
                    throw new SalesmanException(message.ToString());
                }
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmValidated;
        }

        public static bool AddSalesman(Salesman slm)
        {
            bool slmAdded = false;

            try
            {
                if (ValidateSalesman(slm))
                {
                    slmAdded = SalesmanOperations.AddSalesman(slm);
                }
                else
                {
                    throw new SalesmanException("Salesman Details are invalid");
                }
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmAdded;
        }

        public static List<Salesman> DisplayAllSalesman()
        {
            List<Salesman> slmList = null;

            try
            {
                slmList = SalesmanOperations.DisplayAllSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmList;
        }

        public static bool SerializeSalesman()
        {
            bool slmSerialized = false;

            try
            {
                slmSerialized = SalesmanOperations.SerializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmSerialized;
        }

        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> slmList = null;

            try
            {
                slmList = SalesmanOperations.DeserializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return slmList;
        }

    }
}
