﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRS.Exception
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name :Hitesh Jaiswal
    /// Description : User defined Exception class for Salesman
    /// Date of Creation :02/28/2017
    /// </summary>
    public class SalesmanException:ApplicationException
    {
          //Default Constructor
        public SalesmanException()
            : base()
        { }

        //Parameterized Constructor
        public SalesmanException(string message)
            : base(message)
        { }
    }
}
