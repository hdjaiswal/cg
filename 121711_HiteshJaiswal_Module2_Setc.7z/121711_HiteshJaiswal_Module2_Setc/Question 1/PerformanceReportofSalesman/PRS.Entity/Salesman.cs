﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRS.Entity
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : This class have the structure of SalesMan 
    /// Date of Creation : 02/28/2017
    /// </summary>
    [Serializable]
    public class Salesman
    {
        //Get or Set SalesManCode
        public string SalesmanCode { get; set; }

  
        public string Name { get; set; }

      
        public string Zone { get; set; }

    
        public string Region { get; set; }

    
        public DateTime Date { get; set; }

  
        public string ProductCode { get; set; }

        public double TargetSet { get; set; }

        public double ActualSales { get; set; }

        public double Variation { get; set; }

        public string Remarks { get; set; }


            
    }
}
