﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflectionof.EntityClass
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : Reflection class will give the Fields,Methods,Properties,Conctructors of PRS.Entity Library
    /// Date of Creation : 02/28/2017
    /// </summary>
    class Reflection
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("PRS.Entity.dll");
           
            Type dis = refAssembly.GetType("PRS.Entity.Salesman");
     
            Console.WriteLine("\n-----------------------Properties of PRS.Enity Class-------------------------\n");
            PropertyInfo[] pinfo = dis.GetProperties();

            foreach (PropertyInfo m in pinfo)
            {
                Console.WriteLine("----------------------Name : " + m.Name);
                Console.WriteLine("Proprty Type: " + m.PropertyType);
                Console.WriteLine("Membeer Type : " + m.MemberType);
                Console.WriteLine("Attributes: " + m.Attributes);
                Console.WriteLine("Custom Attributes: " + m.CustomAttributes);
                Console.WriteLine("\n");
            }

            Console.WriteLine("\n-----------------------Methods of PRS.Enity Class-------------------------\n");
            MethodInfo[] disMethod = dis.GetMethods();

            for (int i = 0; i < disMethod.Length; i++)
            {
                Console.WriteLine("-----------------------Name : " + disMethod[i].Name);
                Console.WriteLine("Is Private : " + disMethod[i].IsPrivate);
                Console.WriteLine("Is Public : " + disMethod[i].IsPublic);
                Console.WriteLine("Is Static : " + disMethod[i].IsStatic);
                Console.WriteLine("Is Constructor : " + disMethod[i].IsConstructor);
                Console.WriteLine("Return Type : " + disMethod[i].ReturnType);
                ParameterInfo[] param = disMethod[i].GetParameters();
                Console.WriteLine("No of Parameters : " + param.Length);
                Console.WriteLine("Is Constructor : " + disMethod[i].IsConstructor);
                Console.WriteLine("\n");
            }

            Console.WriteLine("\n-----------------------Fields of PRS.Enity Class-------------------------\n");
            FieldInfo[] disField = dis.GetFields();

            for (int i = 0; i < disField.Length; i++)
            {
                Console.WriteLine("----------------------Name: " + disField[i].Name);
                Console.WriteLine("Is Static: " + disField[i].IsStatic);
                Console.WriteLine("Method Type: " + disField[i].MemberType);
                Console.WriteLine("Member Type: " + disField[i].IsPublic);
                Console.WriteLine("Is Private: " + disField[i].IsPrivate);
                Console.WriteLine("Declaring Type: " + disField[i].DeclaringType);
                Console.WriteLine("Is Family: " + disField[i].IsFamily);
                Console.WriteLine("Is Family and Assembly: " + disField[i].IsFamilyAndAssembly);
                Console.WriteLine("\n");
            }

            Console.WriteLine("\n-----------------------Constructors of PRS.Enity Class-------------------------\n");
            ConstructorInfo[] disConstructor = dis.GetConstructors();
            for (int i = 0; i < disConstructor.Length; i++)
            {
                Console.WriteLine("----------------------Name: " + disConstructor[i].Name);
                Console.WriteLine("Attributes: " + disConstructor[i].Attributes);
                Console.WriteLine("Calling Convention: " + disConstructor[i].CallingConvention);
                Console.WriteLine("Is Contains Generic Parameter: " + disConstructor[i].ContainsGenericParameters);
                Console.WriteLine("Declaring Type: " + disConstructor[i].DeclaringType);
                Console.WriteLine("Is Assembly: " + disConstructor[i].IsAssembly);
                Console.WriteLine("Is Final: " + disConstructor[i].IsFinal);
                Console.WriteLine("Is Generic Method: " + disConstructor[i].IsGenericMethod);
                Console.WriteLine("Is Private: " + disConstructor[i].IsPrivate);
                Console.WriteLine("Is Public: " + disConstructor[i].IsPublic);
                Console.WriteLine("\n");
            }
            Console.ReadKey();

        }
    }
}
