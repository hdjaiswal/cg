﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CustomerInformation
{
    /// <summary>
    /// Employee ID :121711
    /// Employee Name : Hitesh Jaiswal
    /// Description : Creation of file CustomerDetails.txt using StreamWriter and input data and read the data of this file
    /// Date of Creation : 02/28/2017
    /// </summary
    
    public class Customer
    {
        static void Main(string[] args)
        {
            try
            {
                FileStream fs = new FileStream("CutomerDetails.txt", FileMode.Create, FileAccess.Write);
                //Creation of File using Filestream

                StreamWriter bw = new StreamWriter(fs);
                FileInfo fi1=new FileInfo("CutomerDetails.txt");

                bw.WriteLine("This are the Customer Details for the year 2015-2016.");
                bw.WriteLine("Most of our Cutomers are from east zone.");
                //Writting data into file CustomerDetails.txt using StreamWriter
              
                bw.Flush();
                //Flush the data of File CustomerDetails.txt
                fs.Close();
                // Close  theFile 
               
                if(fi1.Exists) //check whether file CustomerDetails.txt is created or not
                {
                     Console.WriteLine("\nCustomerDetails.txt File is created and written Successfully");
                }
                else
                {
                    throw new FileNotFoundException("\nCustomerDetails.txt File is not created");
                }
            }

            catch (FileNotFoundException ex) //Catch the message thrown by try block
            {
                Console.WriteLine(ex.Message); //Print the message 
            }
           

            try
            {
                FileInfo fi2 = new FileInfo("CutomerDetails.txt");
                if (fi2.Exists)
                {
                    Console.WriteLine("\nCustomer Details are:\n");
                    FileStream fs1 = new FileStream("CutomerDetails.txt", FileMode.Open, FileAccess.Read);
                    StreamReader br = new StreamReader(fs1);
                    //Read data of File CustomerDetails.txt using StreamReader

                    Console.WriteLine(br.ReadToEnd());
                    //Read the data of File CustomerDetails.txt
                    fs1.Close();
                }
                else
                {
                    throw new FileNotFoundException("\nCustomerDetails.txt File is not Found");
                }
            }

            catch (FileNotFoundException ex) //Catch the message thrown by try block
            {
                Console.WriteLine(ex.Message); //Print the message 
            }
            Console.ReadKey();
        }
    }
}