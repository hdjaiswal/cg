﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    public class UserOperations
    {
        public static string ValidateLogin(User user)
        {
            string userName = null;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "usp_ValidateLogin";

                cmd.Parameters.AddWithValue("@User", user.UserName);
                cmd.Parameters.AddWithValue("@Password", user.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr[0].ToString();
                }
                else
                {
                    throw new UserException("User Name/Password is invalid");
                }

                cmd.Connection.Close();
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
