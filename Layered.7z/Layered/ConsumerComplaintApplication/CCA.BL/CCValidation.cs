﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CCA.Entity;
using CCA.Exception;
using CCA.DAL;

namespace CCA.BL
{
    public class CCValidation
    {
        CCOperation oprObj = new CCOperation();

        public bool ValidComplDetails(ConsumerComplaint conComp)
        {

            bool validComplaint = true;
            StringBuilder sb = new StringBuilder();
           //validate category
            if (conComp.Category.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Category is required.");
            }
            else if (conComp.Category.ToLower() != "domestic" && conComp.Category.ToLower() != "commercial" && conComp.Category.ToLower() != "educational" && conComp.Category.ToLower() != "medicine" && conComp.Category.ToLower() != "other")
            {
                sb.Append("Invalid category.\n");
                validComplaint = false;
            }


            //validate Product name
            if (conComp.ProductName.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product Name is required.");
            }

            //validate date
            if (conComp.DoP.ToString().Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Date of purchase is required.");
            }
            else if (conComp.DoP > DateTime.Today)
            {
                sb.Append("Date of purchase should be less than or equal to current date\n");
                validComplaint = false;
            }


            //validate Dealer Details
            if (conComp.DealerDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Dealer Details are required.");
            }
                       

            //Validate Product value
            if (conComp.ProductValue.ToString().Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product value is required.");
            }

            //validate city
            if (conComp.city.Length == 0 && conComp.DealerDetails.Length < 3)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "City is required.");
            }

            //validate Complaint details
            if (conComp.complaintDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaint details are required.");
            }
            else if (conComp.complaintDetails.Length > 200)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaint details are exceeding 200 characters.");
            }


            if (validComplaint == false)
                throw new CCException(sb.ToString());
            return validComplaint;
        }

        public bool AddComplaintRecord(ConsumerComplaint complObj)
        {
            bool complAdded = false;
            if (ValidComplDetails(complObj))
                complAdded = oprObj.AddComplaintRecord(complObj);
            return complAdded;
        }
        public bool GetConsumerEID(string consEID)
        {

            bool result = oprObj.CompareConsumerEID(consEID);
            return result;
        }

        //public bool CompareConsumerName(string consN)
        //{

        //    bool result = oprObj.CompareConsumerName(consN);
        //    return result;
        //}
    }
}
