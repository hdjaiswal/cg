﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CCA.Entity;
using CCA.Exception;
using System.Data.SqlClient;
using CCA.BL;


namespace CCA.PL
{
    public partial class ComplaintApplication : Form
    {
        CCValidation valObj = new CCValidation();
        public ComplaintApplication()
        {
            
            InitializeComponent();
            mainPanel.Visible = false;
            registerLink.Enabled= false;
        }

        private void btn_Verify_Click(object sender, EventArgs e)
        {
            string consEID = txtEID.Text;
            if (valObj.GetConsumerEID(consEID)){
                // mainPanel.Visible = true;
                registerLink.Enabled = true;
            }
            else
            {
                MessageBox.Show("You are not registered user!!Please register & raise complaint.");
                txtEID.Clear();
                txtEID.Focus();
            }

            //string Name = txtEID.Text;
            //if (valObj.CompareConsumerName(Name))
            //    // mainPanel.Visible = true;
            //    registerLink.Enabled = true;
            //else
            //{
            //    MessageBox.Show("You are not registered user!!Please register & raise complaint.");
            //    txtEID.Focus();
            //}
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            try
            {
                ConsumerComplaint consumerObj = new ConsumerComplaint();

                consumerObj.Category = comboBox1.Text;
                consumerObj.ProductName = txtProdName.Text;
                consumerObj.ProductValue = Convert.ToInt32(txtProdValue.Text);
                consumerObj.ConsumerEID = txtEID.Text;
                consumerObj.city = txtCity.Text;
                consumerObj.DoP = Convert.ToDateTime(dateOfPurch.Text);
                consumerObj.DealerDetails = txtDealerDet.Text;
                consumerObj.complaintDetails = txtCompDet.Text;



                bool consumerAdded = valObj.AddComplaintRecord(consumerObj);
                if (consumerAdded)
                    MessageBox.Show("Dear Customer,Our Executive will get back to you", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Register", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CCException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void registerLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            mainPanel.Visible = true;
        }
    }
}
