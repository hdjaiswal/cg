
--Creating consumer table
CREATE TABLE Consumer_121649
(
	ConsumerEID varchar(40) PRIMARY KEY,
	ConsumerName varchar(20),
	MobileNumber bigint,
	ConsumerAddress varchar(40)
)
Go

--Creating table to store complaint details
CREATE TABLE ComplaintDetails_121649
(
 ComplaintID int identity(1,1) Primary Key,
 ConsumerEID varchar(40) references Consumer_121649(ConsumerEID),
 Category varchar(20),
 ProductName varchar(20),
 DateOfPurchase DateTime,
 ProductValue int,
 DealerDetails varchar(100),
 City varchar(15),
 ComplaintDetails varchar(200)
 )
 Go

 --inserting values in consumer table
 insert into Consumer_121649 values('arti.l2@gmailcom','Arti',9822231045,'Mumbai');
 insert into Consumer_121649 values('shradz21@gmailcom','Shraddha',9821231045,'Karjat');
 insert into Consumer_121649 values('chandumahu@gmailcom','Chandravati',9857426812,'Panvel');
 insert into Consumer_121649 values('piyughosla@gmailcom','Priyanka',7845987524,'Thane');
 insert into Consumer_121649 values('karanarjun@gmailcom','Karan',8954671547,'Mulund');
 insert into Consumer_121649 values('vishalgupta@gmailcom','Vishal',9545102394,'Dadar');
 select * from Consumer_121649
 select * from ComplaintDetails_121649
Go

create procedure AddConsCompl_1216149
(
	@ConsumerEID varchar(40),
	@Category varchar(20),
	@ProductName varchar(20),
	@DateOfPurchase DateTime,
	@ProductValue int,
	@DealerDetails varchar(100),
	@City varchar(15),
	@ComplaintDetails varchar(200)
)
As
INSERT INTO ComplaintDetails_121649
VALUES(@ConsumerEID,@Category,@ProductName,@DateOfPurchase,@ProductValue,@DealerDetails,@City,@ComplaintDetails)

EXEC AddConsCompl_1216149 'arti.l2@gmailcom','Domestic','Maggie','March 14 2017',20,'Grace Supermarket.Ashok Nagar,Chennai','Chennai','The product is repacked.'
go

CREATE PROCEDURE RetrieveConsID_121649
(
	@ConsumerEID varchar(40)
	
)
AS
IF EXISTS (
SELECT ConsumerEID FROM Consumer_121649 
WHERE ConsumerEID=@ConsumerEID
)
  BEGIN
        RETURN 1
    END
ELSE
    BEGIN
        RETURN 0
    END
go

drop procedure RetrieveConsName_121649

EXEC RetrieveConsName_121649 'arti.l2@gmail.com'
go

CREATE PROCEDURE RetrieveConsName_121649
(
	@ConsumerName varchar(20)
	
)
AS
IF EXISTS (
SELECT ConsumerName FROM Consumer_121649 
WHERE ConsumerName=@ConsumerName
)
  BEGIN
        SELECT 1
    END
ELSE
    BEGIN
        SELECT 0
    END
go

drop PROCEDURE RetrieveConsName_121649

EXEC RetrieveConsName_121649 'Arti'
go

CREATE procedure CompareConsEID_121649
(
@ConsumerEID varchar(40)
)
AS

BEGIN
DECLARE @AlphabetPlus VARCHAR(255)
      , @Max INT -- Length of the address
      , @Pos INT -- Position in @EmailAddr
      , @OK BIT  -- Is @EmailAddr OK
-- Check basic conditions
IF @ConsumerEID IS NULL 
   OR NOT  @ConsumerEID  LIKE '_%@__%.__%' 
   OR CHARINDEX(' ',LTRIM(RTRIM(@EmailAddr))) > 0
       RETURN(0)
SELECT @AlphabetPlus = 'abcdefghijklmnopqrstuvwxyz01234567890_-.@'
     , @Max = LEN(@EmailAddr)
     , @Pos = 0
     , @OK = 1
WHILE @Pos < @Max AND @OK = 1 BEGIN
    SET @Pos = @Pos + 1
    IF NOT @AlphabetPlus LIKE '%' 
                             + SUBSTRING(@EmailAddr, @Pos, 1) 
                             + '%' 
        SET @OK = 0
END 
SELECT @OK
END
go
  
