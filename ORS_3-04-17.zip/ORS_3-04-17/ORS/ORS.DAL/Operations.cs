﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLib;


namespace ORS.DAL
{
    public class Operations
    {
        SqlConnection connection;
        SqlDataReader reader;

         public Operations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

         public bool AddJobSeekerPDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddJobseekers", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", jobj.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", jobj.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", jobj.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", jobj.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", jobj.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", jobj.JPassword);
              //   cmdAdd.Parameters.AddWithValue("@", jobj.JCnfPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", jobj.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", jobj.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", jobj.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", jobj.JMaritalStatus);
               
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();
                

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         

         public bool AddJobSeekerQDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.JobseekersQualificationDetail", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@Degree", jobj.Degree);
                 cmdAdd.Parameters.AddWithValue("@Branch", jobj.Branch);
                 cmdAdd.Parameters.AddWithValue("@Passingyear", jobj.PassingYr);
                 cmdAdd.Parameters.AddWithValue("@Percentage", jobj.Percentage);
                 cmdAdd.Parameters.AddWithValue("@UniversityName", jobj.UniversityName);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jobj.JobSeekerID);
                 
              
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         public bool AddJobSeekerPrDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddProfessionaDetails", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jobj.JobSeekerID);
                 cmdAdd.Parameters.AddWithValue("@CurrentDesignation", jobj.JCurrentDesig);
                 cmdAdd.Parameters.AddWithValue("@PrimarySkills", jobj.JPrimarySkills);
                 cmdAdd.Parameters.AddWithValue("@SecondarySkills", jobj.JSecondarySkills);
                 cmdAdd.Parameters.AddWithValue("@TrainingAttended", jobj.JTrainingAttd);
                 cmdAdd.Parameters.AddWithValue("@Designation", jobj.JDesignation);
                 cmdAdd.Parameters.AddWithValue("@Location", jobj.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Experience", jobj.JExperience);


                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         public bool AddEmployeeDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddEmployee", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", jobj.EFirstName);
                 cmdAdd.Parameters.AddWithValue("@LastName", jobj.ELastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", jobj.EEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@Companyname", jobj.ECompanyName);
                 cmdAdd.Parameters.AddWithValue("@Password", jobj.EPassword);
                 cmdAdd.Parameters.AddWithValue("@Designation", jobj.EDesignation);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", jobj.EPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Location", jobj.ELocation);
            
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

      

         public bool AddJobs(ORSEntity jobj)
         {
             try
             {
                 bool jobsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddJobs", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@CompanyName", jobj.DCompanyName);
                 cmdAdd.Parameters.AddWithValue("@Post", jobj.DPost);
                 cmdAdd.Parameters.AddWithValue("@Vacancies", jobj.DVacancies);
                 cmdAdd.Parameters.AddWithValue("@PostedDate", jobj.DPostedDate);
                 cmdAdd.Parameters.AddWithValue("@LastDate", jobj.DLastDate);
                 cmdAdd.Parameters.AddWithValue("@CompanyDescription", jobj.DDescription);
                 cmdAdd.Parameters.AddWithValue("@JobLocation", jobj.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Package", jobj.DPackage);
                 cmdAdd.Parameters.AddWithValue("@Experience", jobj.DExperience);
                 cmdAdd.Parameters.AddWithValue("@EmployeeID", jobj.EmployeeID);

                 if (connection.State == ConnectionState.Closed) 
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jobsAdded = true;
                 return jobsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         public DataTable GetEmpID(string email,string password)
         {
             SqlCommand cmdGetEmpID = new SqlCommand("ORSGroup6.EmployeeVerification", connection);
             cmdGetEmpID.CommandType = CommandType.StoredProcedure;
             cmdGetEmpID.Parameters.AddWithValue("@EmailAddress", email);
             cmdGetEmpID.Parameters.AddWithValue("@Password", password);
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdGetEmpID.ExecuteReader();
             DataTable empTable = new DataTable();
             empTable.Load(reader);
             return empTable;

         }

         public DataTable GetAppliedDetails(int empid, int jobid)
         {
             SqlCommand cmdgetjapldetails = new SqlCommand("ORSGroup6.ViewsJobAppliedDetails", connection);
             cmdgetjapldetails.CommandType = CommandType.StoredProcedure;
             cmdgetjapldetails.Parameters.AddWithValue("@EmployeeId", empid);
             cmdgetjapldetails.Parameters.AddWithValue("@JobId", jobid);
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdgetjapldetails.ExecuteReader();
             DataTable jobTable = new DataTable();
             jobTable.Load(reader);
             return jobTable;

         }

         public DataTable GetJSID(string email,string password)
         {
             SqlCommand cmdGetJSID = new SqlCommand("ORSGroup6.VerificationJobseekers", connection);
             cmdGetJSID.CommandType = CommandType.StoredProcedure;
             cmdGetJSID.Parameters.AddWithValue("@EmailAddress", email);
             cmdGetJSID.Parameters.AddWithValue("@Password", password);

             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdGetJSID.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

       

         public DataTable GetPostedJobs(int empid)
         {
             SqlCommand cmdPJobs = new SqlCommand("ORSGroup6.ViewjobsByEmployee", connection);
             cmdPJobs.CommandType = CommandType.StoredProcedure;
             cmdPJobs.Parameters.AddWithValue("@EmployeeID", empid);
           
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdPJobs.ExecuteReader();
             DataTable jobTable = new DataTable();
             jobTable.Load(reader);
             return jobTable;

         }

         public DataTable GetPDetails(int jsid)
         {
             ORSEntity pdObj = new ORSEntity();
             SqlCommand cmdjsdetails = new SqlCommand("ORSGroup6.RetieveJobseekersPersonalDetails", connection);
             cmdjsdetails.CommandType = CommandType.StoredProcedure;
             cmdjsdetails.Parameters.AddWithValue("@jobseekerID", jsid);

             if (connection.State == ConnectionState.Closed)
                 connection.Open();

             reader = cmdjsdetails.ExecuteReader();
             DataTable jdetailsTable = new DataTable();
             jdetailsTable.Load(reader);
             return jdetailsTable;
         }

         public DataTable GetProfDetails(int jsid)
         {
             ORSEntity profObj = new ORSEntity();
             SqlCommand cmdjsdetails = new SqlCommand("ORSGroup6.RetrieveProfessionaldetails", connection);
             cmdjsdetails.CommandType = CommandType.StoredProcedure;
             cmdjsdetails.Parameters.AddWithValue("@JobSeekerID", jsid);

             if (connection.State == ConnectionState.Closed)
                 connection.Open();

             reader = cmdjsdetails.ExecuteReader();
             DataTable jdetailsTable = new DataTable();
             jdetailsTable.Load(reader);
             return jdetailsTable;

         }

         public bool UpdatePersonalDetails(ORSEntity jsObj)
         {
             try
             {
                 bool pedUpdated = false;
                 SqlCommand cmdupdate = new SqlCommand("UpdatePersonalDetails", connection);
                 cmdupdate.CommandType = CommandType.StoredProcedure;
                 cmdupdate.Parameters.AddWithValue("@JobSeekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@FirstName", jsObj.JFirstName);
                 cmdupdate.Parameters.AddWithValue("@LastName", jsObj.JLastName);
                 cmdupdate.Parameters.AddWithValue("@MiddleName", jsObj.JMiddleName);
                 cmdupdate.Parameters.AddWithValue("@ContactNo", jsObj.JPhoneNo);
                 cmdupdate.Parameters.AddWithValue("@Gender", jsObj.JGender);
                 cmdupdate.Parameters.AddWithValue("@MarraigeStatus", jsObj.JMaritalStatus);
                 cmdupdate.Parameters.AddWithValue("@JobSeekersAddress", jsObj.JAddress);
                 cmdupdate.Parameters.AddWithValue("@DOB", jsObj.JDOB);
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdupdate.ExecuteNonQuery();

                 if (result > 0)
                     pedUpdated = true;
                 return pedUpdated;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }

         }

         public bool UpdateProfessionalDetails(ORSEntity jsObj)
         {
             try
             {
                 bool profUpdated = false;
                 SqlCommand cmdupdate = new SqlCommand("UpdateProfesionalDetails", connection);
                 cmdupdate.CommandType = CommandType.StoredProcedure;
                 cmdupdate.Parameters.AddWithValue("@jobseekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@CurrentDesignation", jsObj.JCurrentDesig);
                 cmdupdate.Parameters.AddWithValue("@PrimarySkills", jsObj.JPrimarySkills);
                 cmdupdate.Parameters.AddWithValue("@SecondarySkills", jsObj.JSecondarySkills);
                 cmdupdate.Parameters.AddWithValue("@TrainingAttended", jsObj.JTrainingAttd);
                 cmdupdate.Parameters.AddWithValue("@Designation", jsObj.JDesignation);
                 cmdupdate.Parameters.AddWithValue("@Location", jsObj.DJobLocation);
                 cmdupdate.Parameters.AddWithValue("@Experience", jsObj.JExperience);
                
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdupdate.ExecuteNonQuery();

                 if (result > 0)
                     profUpdated = true;
                 return profUpdated;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }

         }

         public DataTable SearchByLocation(string jobloc)
         {
             SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyLocation", connection);
             cmdsrchloc.CommandType = CommandType.StoredProcedure;
             cmdsrchloc.Parameters.AddWithValue("@JobLocation", jobloc);
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdsrchloc.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public DataTable SearchByDesignation(string jobdesig)
         {
             SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyDesignation", connection);
             cmdsrchloc.CommandType = CommandType.StoredProcedure;
             cmdsrchloc.Parameters.AddWithValue("@Designation", jobdesig);
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdsrchloc.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public DataTable SearchByExperience(string jobexp)
         {
             SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyExperience", connection);
             cmdsrchloc.CommandType = CommandType.StoredProcedure;
             cmdsrchloc.Parameters.AddWithValue("@Experience", jobexp);
             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdsrchloc.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public DataTable GetjAppliedDetails()
         {
             SqlCommand cmdGetjApdetails = new SqlCommand("Select * from ORSGroup6.AppliedJobs", connection);

             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdGetjApdetails.ExecuteReader();
             DataTable jobTable = new DataTable();
             jobTable.Load(reader);

             return jobTable;

         }


         public DataTable GetQualificationDetails()
         {
             SqlCommand cmdGetqdetails = new SqlCommand("Select * from ORSGroup6.JobseekersQualificationDetails", connection);

             if (connection.State == ConnectionState.Closed)
                 connection.Open();
             reader = cmdGetqdetails.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);

             return jsTable;

         }

         public bool ApplyJobs(ORSEntity jobj)
         {
             try
             {
                 bool jobsApplied = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6.ApplyJobs", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@JobId", jobj.JobID);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerId", jobj.JobSeekerID);
                
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jobsApplied = true;
                 return jobsApplied;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }  
       
    }
}
