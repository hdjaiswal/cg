﻿using ORS.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.Entity;
using ORS.BL;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class SearchJobs : Form
    {
        public SearchJobs()
        {
            InitializeComponent();
        }
        Validations validationObj = new Validations();

        private void btnsrchexp_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();
            SearchJobs frm = new SearchJobs();
            string exp = frm.cmbbx.Text;
            jsTable = validationObj.SearchByExperience(exp);
            if (jsTable != null)
            {
                dgvsrchjobs.DataSource = jsTable;
            }
            else
            {
                MessageBox.Show("Search not found");
            }
        }
   
        private void btnsrchloc_Click(object sender, EventArgs e)
        {
            
        }

        ORSEntity jsObj = new ORSEntity();

        private void btnsubmit_Click(object sender, EventArgs e)
        {

           
        }

        private void btnsrchloc_Click_1(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();

            string loc = txtloc.Text;
            jsTable = validationObj.SearchByLocation(loc);
            if (jsTable != null)
            {
                dgvsrchjobs.DataSource = jsTable;
            }
            else
            {
                MessageBox.Show("Location not found ");
            }
        }

        private void btnsrchpost_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();

            string post = txtpost.Text;
            jsTable = validationObj.SearchByDesignation(post);
            if (jsTable != null)
            {
                dgvsrchjobs.DataSource = jsTable;
            }
            else
            {
                MessageBox.Show("Post not found");
            }
        }

        private void btnsrchexp_Click_1(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();
           // SearchJobs frm = new SearchJobs();
            string exp = cmbbx.Text;
            jsTable = validationObj.SearchByExperience(exp);
            if (jsTable != null)
            {
                dgvsrchjobs.DataSource = jsTable;
            }
            else
            {
                MessageBox.Show("Search not found");
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            JobSeeker frm = new JobSeeker();
            frm.Show();
            this.Hide();
        }

        private void SearchJobs_Load(object sender, EventArgs e)
        {
           
        }

        private void btnsubmit_Click_1(object sender, EventArgs e)
        {
            try
            {


                jsObj.JobSeekerID = Convert.ToInt32(txtjbid.Text);
                jsObj.JobID = Convert.ToInt32(txtjobid.Text);
               

                validationObj.ApplyJobs(jsObj);
                MessageBox.Show("You have applied successfully");

            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
