﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;
using System.Configuration;

namespace ProjectNew
{
    public partial class frmHomePage : Form
    {
        private int imageNumber = 1;

        private void loadNextImage()
        {
            if (imageNumber == 4)
            {
                imageNumber = 1;
            }
            picBox1.Load(string.Format(@"D:\ORS_3-04-17\ORS\ORS.PL\Images\Img{0}.jpg", imageNumber));
            imageNumber++;
        }

        public static string Euser = null;
        public static string JSuser = null;
         public static string JSFName=null;
        public frmHomePage()
        {
            InitializeComponent();
        }

        ORSEntity jObj = new ORSEntity();
        private void btnJsLogin_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand cmdVerifyJS = new SqlCommand("SELECT EmailAddress,Password FROM ORSGroup6.JobseekersLogin WHERE EmailAddress ='" + txtJsUserName.Text + "'AND Password = '"+ txtJsPassword.Text +"'", connection);
            SqlDataAdapter da = new SqlDataAdapter(cmdVerifyJS);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count>0)
            {
                DataTable jsTable = new DataTable();

                jsTable = eVal.GetJSID(txtJsUserName.Text, txtJsPassword.Text);
                JSID = Convert.ToInt32(jsTable.Rows[0]["jobseekerID"]);
                
                JSuser = txtJsUserName.Text;
           
                ShowInTaskbar = false;
                Visible = false;
                JobSeeker frm = new JobSeeker();
                frm.Show();   
            }
            else
            {
                MessageBox.Show("Please Enter correct username and password");
                txtJsUserName.Text = "";
                txtJsPassword.Text = "";
                txtJsUserName.Focus();
            }
            connection.Close();
        }

        ORSEntity eObj = new ORSEntity();

        public static int Eempid;
        public static int JSID;

        Validations eVal = new Validations();
        private void btnELogin_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand cmdVerifyEmployee = new SqlCommand("SELECT EmailAddress,Password FROM ORSGroup6.EmployeersLogin WHERE EmailAddress ='" + txtEUserName.Text + "'AND Password = '" + txtEPassword.Text + "'", connection);
            SqlDataAdapter da = new SqlDataAdapter(cmdVerifyEmployee);
            DataTable dt = new DataTable();
            da.Fill(dt);
           
            
           
            if (dt.Rows.Count > 0)
            {
                DataTable empTable = new DataTable();

                empTable = eVal.GetEmpID(txtEUserName.Text, txtEPassword.Text);
                Eempid = Convert.ToInt32(empTable.Rows[0]["EmployeeID"]);
                Euser = txtEUserName.Text;
                // this.Hide();
                ShowInTaskbar = false;
                Visible = false;
                Employer frm = new Employer();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Please Enter correct username and password");
                txtEUserName.Text = "";
                txtEPassword.Text = "";
                txtEUserName.Focus();
            }

         
               
            connection.Close();
        }

        private void frmHomePage_Load(object sender, EventArgs e)
        {

        }
        public string UserName // on LoginForm
        {
            get { return txtEUserName.Text; }
        }
        //private void button1_Click(object sender, EventArgs e)
        //{

        //}

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void linkLblJs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            JobSeekerReg1 frm = new JobSeekerReg1();
            frm.Show();
            this.Hide();

        }

        private void lin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            EmployerRegistration frm = new EmployerRegistration();
            frm.Show();
            this.Hide();
        }
    }
}
