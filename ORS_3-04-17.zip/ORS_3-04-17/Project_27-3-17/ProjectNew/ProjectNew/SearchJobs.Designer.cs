﻿namespace ProjectNew
{
    partial class SearchJobs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchJobs));
            this.panelsrchjobs = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtjobid = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnsrchloc = new System.Windows.Forms.Button();
            this.btnsrchpost = new System.Windows.Forms.Button();
            this.btnsrchexp = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.txtloc = new System.Windows.Forms.TextBox();
            this.cmbbx = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtpost = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.dgvsrchjobs = new System.Windows.Forms.DataGridView();
            this.lblPostedJobs = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.jobsActive = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtjbid = new System.Windows.Forms.TextBox();
            this.panelsrchjobs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvsrchjobs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelsrchjobs
            // 
            this.panelsrchjobs.Controls.Add(this.txtjbid);
            this.panelsrchjobs.Controls.Add(this.label1);
            this.panelsrchjobs.Controls.Add(this.btnclose);
            this.panelsrchjobs.Controls.Add(this.label4);
            this.panelsrchjobs.Controls.Add(this.txtjobid);
            this.panelsrchjobs.Controls.Add(this.btnsubmit);
            this.panelsrchjobs.Controls.Add(this.btnsrchloc);
            this.panelsrchjobs.Controls.Add(this.btnsrchpost);
            this.panelsrchjobs.Controls.Add(this.btnsrchexp);
            this.panelsrchjobs.Controls.Add(this.label37);
            this.panelsrchjobs.Controls.Add(this.txtloc);
            this.panelsrchjobs.Controls.Add(this.cmbbx);
            this.panelsrchjobs.Controls.Add(this.label36);
            this.panelsrchjobs.Controls.Add(this.txtpost);
            this.panelsrchjobs.Controls.Add(this.label35);
            this.panelsrchjobs.Controls.Add(this.dgvsrchjobs);
            this.panelsrchjobs.Controls.Add(this.lblPostedJobs);
            this.panelsrchjobs.Location = new System.Drawing.Point(115, 194);
            this.panelsrchjobs.Name = "panelsrchjobs";
            this.panelsrchjobs.Size = new System.Drawing.Size(1128, 604);
            this.panelsrchjobs.TabIndex = 58;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(295, 417);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 16);
            this.label4.TabIndex = 57;
            this.label4.Text = "Enter Job ID";
            // 
            // txtjobid
            // 
            this.txtjobid.Location = new System.Drawing.Point(459, 418);
            this.txtjobid.Name = "txtjobid";
            this.txtjobid.Size = new System.Drawing.Size(119, 20);
            this.txtjobid.TabIndex = 56;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(313, 491);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 55;
            this.btnsubmit.Text = "Apply";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click_1);
            // 
            // btnsrchloc
            // 
            this.btnsrchloc.Location = new System.Drawing.Point(605, 167);
            this.btnsrchloc.Name = "btnsrchloc";
            this.btnsrchloc.Size = new System.Drawing.Size(75, 23);
            this.btnsrchloc.TabIndex = 54;
            this.btnsrchloc.Text = "Search";
            this.btnsrchloc.UseVisualStyleBackColor = true;
            this.btnsrchloc.Click += new System.EventHandler(this.btnsrchloc_Click_1);
            // 
            // btnsrchpost
            // 
            this.btnsrchpost.Location = new System.Drawing.Point(605, 120);
            this.btnsrchpost.Name = "btnsrchpost";
            this.btnsrchpost.Size = new System.Drawing.Size(75, 23);
            this.btnsrchpost.TabIndex = 53;
            this.btnsrchpost.Text = "Search";
            this.btnsrchpost.UseVisualStyleBackColor = true;
            this.btnsrchpost.Click += new System.EventHandler(this.btnsrchpost_Click);
            // 
            // btnsrchexp
            // 
            this.btnsrchexp.Location = new System.Drawing.Point(603, 72);
            this.btnsrchexp.Name = "btnsrchexp";
            this.btnsrchexp.Size = new System.Drawing.Size(75, 23);
            this.btnsrchexp.TabIndex = 52;
            this.btnsrchexp.Text = "Search";
            this.btnsrchexp.UseVisualStyleBackColor = true;
            this.btnsrchexp.Click += new System.EventHandler(this.btnsrchexp_Click_1);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(274, 169);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(67, 16);
            this.label37.TabIndex = 51;
            this.label37.Text = "Location";
            // 
            // txtloc
            // 
            this.txtloc.Location = new System.Drawing.Point(403, 168);
            this.txtloc.Name = "txtloc";
            this.txtloc.Size = new System.Drawing.Size(175, 20);
            this.txtloc.TabIndex = 50;
            // 
            // cmbbx
            // 
            this.cmbbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbx.FormattingEnabled = true;
            this.cmbbx.Items.AddRange(new object[] {
            "Select",
            "0-1 yrs",
            "1-2 yrs",
            "2-3 yrs",
            "3-4 yrs"});
            this.cmbbx.Location = new System.Drawing.Point(405, 72);
            this.cmbbx.Name = "cmbbx";
            this.cmbbx.Size = new System.Drawing.Size(173, 24);
            this.cmbbx.TabIndex = 48;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(271, 75);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(86, 16);
            this.label36.TabIndex = 49;
            this.label36.Text = "Experience";
            // 
            // txtpost
            // 
            this.txtpost.Location = new System.Drawing.Point(405, 123);
            this.txtpost.Name = "txtpost";
            this.txtpost.Size = new System.Drawing.Size(175, 20);
            this.txtpost.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(274, 124);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(39, 16);
            this.label35.TabIndex = 3;
            this.label35.Text = "Post";
            // 
            // dgvsrchjobs
            // 
            this.dgvsrchjobs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvsrchjobs.Location = new System.Drawing.Point(48, 217);
            this.dgvsrchjobs.Name = "dgvsrchjobs";
            this.dgvsrchjobs.Size = new System.Drawing.Size(744, 170);
            this.dgvsrchjobs.TabIndex = 2;
            // 
            // lblPostedJobs
            // 
            this.lblPostedJobs.AutoSize = true;
            this.lblPostedJobs.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostedJobs.Location = new System.Drawing.Point(347, 18);
            this.lblPostedJobs.Name = "lblPostedJobs";
            this.lblPostedJobs.Size = new System.Drawing.Size(143, 25);
            this.lblPostedJobs.TabIndex = 1;
            this.lblPostedJobs.Text = "Search Jobs";
            // 
            // btnclose
            // 
            this.btnclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(442, 491);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 23);
            this.btnclose.TabIndex = 58;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(118, 118);
            this.pictureBox3.TabIndex = 64;
            this.pictureBox3.TabStop = false;
            // 
            // jobsActive
            // 
            this.jobsActive.AutoSize = true;
            this.jobsActive.BackColor = System.Drawing.Color.Transparent;
            this.jobsActive.Font = new System.Drawing.Font("Century Schoolbook", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jobsActive.Location = new System.Drawing.Point(147, 12);
            this.jobsActive.Name = "jobsActive";
            this.jobsActive.Size = new System.Drawing.Size(613, 95);
            this.jobsActive.TabIndex = 65;
            this.jobsActive.Text = "jobactive.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(295, 454);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 16);
            this.label1.TabIndex = 59;
            this.label1.Text = "Enter JobSeeker ID";
            // 
            // txtjbid
            // 
            this.txtjbid.Location = new System.Drawing.Point(461, 454);
            this.txtjbid.Name = "txtjbid";
            this.txtjbid.Size = new System.Drawing.Size(119, 20);
            this.txtjbid.TabIndex = 60;
            // 
            // SearchJobs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 762);
            this.Controls.Add(this.jobsActive);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panelsrchjobs);
            this.Name = "SearchJobs";
            this.Text = "SearchJobs";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.SearchJobs_Load);
            this.panelsrchjobs.ResumeLayout(false);
            this.panelsrchjobs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvsrchjobs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelsrchjobs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtjobid;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnsrchloc;
        private System.Windows.Forms.Button btnsrchpost;
        private System.Windows.Forms.Button btnsrchexp;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtloc;
        private System.Windows.Forms.ComboBox cmbbx;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtpost;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView dgvsrchjobs;
        private System.Windows.Forms.Label lblPostedJobs;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label jobsActive;
        private System.Windows.Forms.TextBox txtjbid;
        private System.Windows.Forms.Label label1;
    }
}