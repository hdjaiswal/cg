﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class JobSeeker: Form
    {
        public JobSeeker()
        {
            InitializeComponent();
        }

        ORSEntity jsObj = new ORSEntity();
        Validations validationObj=new Validations();

        private void JobSeeker_Load(object sender, EventArgs e)
        {
            JSPannel.Visible = true;
          
            label100.Visible = true;
            //label2.Visible = false;
            label3.Visible = false;
         //   label4.Visible = false;
            //btnPersonalDetail1.Visible = false;
            // btnQualificationDetail.Visible = false;
            btnAppliedDetail.Visible = false;
        //    btnSearchjob.Visible = false;
            //btnPDUpdate.Visible = false;
            btnQD1Update.Visible = false;
            panel2.Visible = false;
            panelAddMore1.Visible = false;
            panelAddMore2.Visible = false;
            panelprofdetails.Visible = false;
            //panelsrchjobs.Visible = false;
            int jsID = Convert.ToInt32(label30.Text);
            DataTable jsTable = new DataTable();

            jsTable = validationsObj.GetPDetails(jsID);

            dgvpdetails.DataSource = jsTable;
        }

          
        Validations validationsObj = new Validations();

        private void linkLabelprofdetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
                panelprofdetails.Visible=true;
               // panelsrchjobs.Visible = false;
            label100.Visible = true;
            // btnPersonalDetail1.Visible = true;
            // btnPDUpdate.Visible = true;
            panel2.Visible = true;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
          //  panel4.Visible = false;
           // label4.Visible = false;
            panelAddMore1.Visible = false;
            int jsID = Convert.ToInt32(label30.Text);
            DataTable jsTable = new DataTable();

            jsTable = validationsObj.GetProfDetails(jsID);

            dgvprofdetails.DataSource = jsTable;
        }

      
        private void PDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         
            panel1.Visible = true;
            label100.Visible = true;
            // btnPersonalDetail1.Visible = true;
            // btnPDUpdate.Visible = true;
            panel2.Visible = false;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
           // panel4.Visible = false;
            //label4.Visible = false;
          //  panelsrchjobs.Visible = false;
            panelAddMore1.Visible = false;
            int jsID=Convert.ToInt32(label30.Text);
            DataTable jsTable = new DataTable();

            jsTable = validationsObj.GetPDetails(jsID);

            dgvpdetails.DataSource = jsTable;
            

        }

        private void QDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SearchJob frm = new SearchJob();
            frm.Visible = true;
            this.Hide();
           
        }

        private void AppJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel3.Visible = true;
            label3.Visible = true;
            btnAppliedDetail.Visible = true;
            panel1.Visible = false;
           // label100.Visible = false;
            panel2.Visible = false;
            //label2.Visible = false;
         //   panel4.Visible = false;
          //  label4.Visible = false;
            panelAddMore1.Visible = false;
           // panelsrchjobs.Visible = false;  
        }

       
        private void SearchJobs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //SearchJobs frm = new SearchJobs();
            //frm.Visible = true;
            //this.Hide();
        }

        private void btnSearchjob_Click(object sender, EventArgs e)
        {
           // panel4.Visible = false;
            panel1.Visible = true;
        }

        private void btnAppliedDetail_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel1.Visible = true;
        }

        private void btnQualificationDetail_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void btnPersonalDetail1_Click(object sender, EventArgs e)
        {
           // panel1.Visible = false;
        }

        private void btnPDUpdate_Click(object sender, EventArgs e)
        {
            //panel1.Visible = false;
            MessageBox.Show("Personal Details Updated Sucessfully");
        }

        private void btnQD1Update_Click(object sender, EventArgs e)
        {
           // panel2.Visible = false;
            MessageBox.Show("Qualification Details Updated Sucessfully");
        }

 

        private void btnUpdateQD1_Click(object sender, EventArgs e)
        {
            panelAddMore1.Visible = true;
            panelAddMore2.Visible = false;
        }


        private void linkLblLogO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Are you sure want to logout", "Please Confirm", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }

        private void JobSeeker_Activated(object sender, EventArgs e)
        {
            label1000.Text = frmHomePage.JSuser;
            label30.Text = Convert.ToString(frmHomePage.JSID);
        }

        private void btnQD2Update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnSubmitSsc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnSubmitHsc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnUpdateQD2_Click(object sender, EventArgs e)
        {
            panelAddMore2.Visible = true;
        }

        private void label1000_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
            ORSEntity updateObj = new ORSEntity();
            updateObj.JobSeekerID = Convert.ToInt16(label30.Text);
            updateObj.JFirstName = txtJsFName.Text;
            updateObj.JLastName = txtJsLName.Text;
            updateObj.JMiddleName = txtJsMName.Text;
            if (radioButton1.Checked)
            {
                updateObj.JGender = radioButton1.Text;
            }
            else
            {
                updateObj.JGender = radioButton2.Text;
            }

            if (radioButton3.Checked)
            {
                updateObj.JMaritalStatus = radioButton3.Text;
            }
            else
            {
                 updateObj.JMaritalStatus = radioButton4.Text;
            }
            updateObj.JPhoneNo = Convert.ToInt64(txtJsContactNo.Text);
            updateObj.JAddress = txtJsAddress.Text;
            updateObj.JDOB = Convert.ToDateTime(dateTimePicker1.Text);

             bool pedUpdated = validationsObj.UpdatePersonalDetails(updateObj);
                if (pedUpdated)
                    MessageBox.Show("Personal Details Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update Personal Details record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnupdateprofd_Click(object sender, EventArgs e)
        {
            try
            {
                ORSEntity updateObj = new ORSEntity();
                updateObj.JobSeekerID = Convert.ToInt16(label30.Text);
                updateObj.JCurrentDesig = txtJscurdesig.Text;;
                updateObj.JPrimarySkills = txtJsPrimSkills.Text;
                updateObj.JSecondarySkills = txtJsSecSkills.Text;
                updateObj.JTrainingAttd=txtJsCertiCourses.Text;
                updateObj.JDesignation=txtJsDesignation.Text;
                updateObj.DJobLocation=txtJsLocation.Text;;
                updateObj.JExperience=cmbJsExp.Text;
                
                bool pedUpdated = validationsObj.UpdateProfessionalDetails(updateObj);
                if (pedUpdated)
                    MessageBox.Show("Professional Details Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update Professional Details record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    
        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void linksrchjobs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SearchJobs frm = new SearchJobs();
            frm.Visible = true;
            this.Hide();

            DataTable jsTable = new DataTable();

          
            panelprofdetails.Visible = false;
       
            label100.Visible = true;
        
            panel2.Visible = false;
     
            panel3.Visible = false;
            label3.Visible = false;
            panel1.Visible = false;
           
            panelAddMore1.Visible = false;
        }

       

       

      
    }
}
