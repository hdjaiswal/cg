﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;
using System.Configuration;

namespace ProjectNew
{
    public partial class SearchJob : Form
    {
        public SearchJob()
        {
            InitializeComponent();
        }

        Validations validationObj = new Validations();
        ORSEntity jsObj = new ORSEntity();

        private void btnJsReg2_Click(object sender, EventArgs e)
        {
            

            try
            {
                jsObj.JobSeekerID = Convert.ToInt32(txtregid.Text);
                jsObj.PassingYr = Convert.ToInt32(txtPassingYr.Text);
                jsObj.Percentage = Convert.ToDouble(txtJsPercentage.Text);
                jsObj.UniversityName = txtUniversityName.Text;
             
                jsObj.Degree = cmbdegree.Text;
                jsObj.Branch = txtJsBranch.Text;
              

                validationObj.AddJobSeekerQDetails(jsObj);
                MessageBox.Show("Records saved successfully");
                
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtPassyr_TextChanged(object sender, EventArgs e)
        {

        }
      

        private void JobSeekerReg2_Load(object sender, EventArgs e)
        {
           
          
        }

        private void JobSeekerReg2_Activated(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            txtregid.Clear();
            txtUniversityName.Clear();
            txtPassingYr.Clear();
            txtJsPercentage.Clear();
            txtJsBranch.Clear();
            
            txtregid.Focus();
        }

        Validations validationsObj = new Validations();
        private void button1_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();

            jsTable = validationsObj.GetQualificationDetails();

            dgvqdetails.DataSource = jsTable;
        }

        private void btnclo_Click(object sender, EventArgs e)
        {
            JobSeeker frm = new JobSeeker();
            frm.Show();
            this.Hide();
        }
    }
}
