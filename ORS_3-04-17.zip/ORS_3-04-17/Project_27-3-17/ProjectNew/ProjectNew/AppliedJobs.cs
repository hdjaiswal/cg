﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;

namespace ProjectNew
{
    public partial class AppliedJobs : Form
    {
        public AppliedJobs()
        {
            InitializeComponent();
        }
        Validations objvalidation = new Validations();

        private void btnclose_Click(object sender, EventArgs e)
        {
            Employer frm = new Employer();
            frm.Show();
            this.Hide();
        }

        private void AppliedJobs_Load(object sender, EventArgs e)
        {
          
        }

        private void btnsrch_Click(object sender, System.EventArgs e)
        {
            DataTable jobTable = new DataTable();
            int empid = Convert.ToInt32(txtempid.Text);
            int jobid = Convert.ToInt32(txtjobid.Text);

            jobTable = objvalidation.GetAppliedDetails(empid,jobid);

            dgvappldetails.DataSource = jobTable;
        }
    }
}
