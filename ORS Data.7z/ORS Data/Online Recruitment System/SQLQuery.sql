
-- Database for Online Recruitment System Group 6

Create Schema ORSGRP6


--Table for Login Details

CREATE TABLE LoginDetails
(
LoginID int Constraint PK_Login Primary Key,
UserName varchar(20),
Password varchar(20),
EmployeeID int,
JobSeekerID int,
LastLogTime DateTime
);

--Table for Job Seeker Information

CREATE TABLE JobSeekersPersonalInfo
(
JobSeekerID int Primary Key,
ContactNo bigint,
EmailAddress varchar(50),
JobSeekersAddress varchar(50),
DOB DateTime
);


--Table for JobSeeker Professional Details
Create Table JobSeekerProfessionalInfo
(
JobSeekerID int Constraint FK_JSInfo References JobSeekersPersonalInfo(JobSeekerID),
CurrentDesignation varchar(20),
PrimarySkills varchar(50),
SecondarySkills varchar(50),
Qualification varchar(50),
TrainingAttended varchar(30),
Designation varchar(20),
Location varchar(30),
Experience int
);


--Table for Job Details
Create Table JobDetails
(
JobID int Constraint PK_JDetails Primary Key,
EmployeeID int Constraint FK_JDetails References LoginDetails(EmployeeID),
JobDescription varchar(50),
Location varchar(30),
Designation varchar(50),
Salary decimal,
Experience int,
SkillSet varchar(50),
PostedDate DateTime,
LastDate DateTime
);

--Table for Applied Job Details
Create Table JobAppliedDetails
(
JobID int Constraint FK_JADetails References JobDetails(JobID),
EmployeeID int Constraint FK_JDetails References LoginDetails(EmployeeID),
JobDescrpition varchar(50),
PostDate DateTime,
LastDate DateTime,
JobSeekerID int Constraint FK_JSInfo References JobSeekersPersonalInfo(JobSeekerID)
);

--Table for Employee Details
Create Table EmployeeDetails
(
EmployeeID int Constraint FK_JDetails References LoginDetails(EmployeeID),
FirstName varchar(20),
LastName varchar(20),
CompanyID int,
Designation varchar(20),
Location varchar(20),
ContactNO bigint,
EmailAddress varchar(20)
);


 
