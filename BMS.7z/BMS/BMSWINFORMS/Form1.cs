﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using BMS.Entities;
using BMS.BL;
using BMS.Exceptions;

namespace BMSWINFORMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetAllBooks()
        {
            try
            {
                List<Book> booklist = BMSBL.GetAllBookBL();

                dataGridView1.DataSource = booklist.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GetAllBooks();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Book newbook = new Book();
                newbook.BookName = txtBookname.Text;
                newbook.Author = txtAuthor.Text;
                newbook.Price = Convert.ToDouble(txtPrice.Text);

                bool status = BMSBL.AddBookBL(newbook);

                if (status)
                {
                    MessageBox.Show("Book Added");
                    GetAllBooks();

                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to add book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); ;
            }
        }

        private void ClearFields()
        {
            txtBookname.Text = "";
            txtAuthor.Text = "";
            txtPrice.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Book book = null;
                int id = Convert.ToInt32(txtID.Text);
                book = BMSBL.GetBookBL(id);

                if (book != null)
                {
                    MessageBox.Show("Book Found...");
                    txtBookname.Text = book.BookName;
                    txtAuthor.Text = book.Author;
                    txtPrice.Text = book.Price.ToString();
                }
                else
                {
                    MessageBox.Show("Unable to Find Book....");
                    txtID.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Book updatebook = new Book();
                updatebook.BookName = txtBookname.Text;
                updatebook.Author = txtAuthor.Text;
                updatebook.Price = Convert.ToDouble(txtPrice.Text);
                updatebook.BookId = Convert.ToInt32(txtID.Text);

                bool status = BMSBL.UpdateBookBL(updatebook);

                if (status)
                {
                    MessageBox.Show("Book Updated");
                    ClearFields();
                    GetAllBooks();
                }
                else
                {
                    MessageBox.Show("Unable to Update Book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtID.Text);
                bool status = BMSBL.DeleteBookBL(id);

                if (status)
                {
                    MessageBox.Show("Book Deleted");
                    ClearFields();
                    GetAllBooks();
                }
                else
                {
                    MessageBox.Show("Unable to delete book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
