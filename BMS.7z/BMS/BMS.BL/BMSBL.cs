﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BMS.Entities;
using BMS.DAL;
using BMS.Exceptions;

namespace BMS.BL
{
    public class BMSBL
    {
        public static bool ValidateBook(Book book)
        {
            bool result = true;
            StringBuilder sb = new StringBuilder();

            if (book.BookName == string.Empty)
            {
                result = false;
                sb.Append("BookName cannot be blank");
            }

            if (book.Author == string.Empty)
            {
                result = false;
                sb.Append("Authot Name Cannot be blank");
            }
            if (book.Price <= 0)
            {
                result = false;
                sb.Append("Price cannot be negative or zero");
            }

            if (result == false)
            {
                throw new BookException(sb.ToString());
            }
            return result;
        }

        public static bool AddBookBL(Book book)
        {
            bool bookaddded = false;
            try
            {
                if (ValidateBook(book))
                {
                    BMSDAL obj = new BMSDAL();
                    bookaddded = obj.AddBookDAL(book);
                }
            }
            catch (Exception ex)
            {
                throw new BookException(ex.Message);
            }

            return bookaddded;
        }

        public static List<Book> GetAllBookBL()
        {
            List<Book> bookllist = null;

            try
            {
                BMSDAL bmsdal = new BMSDAL();
                bookllist = bmsdal.GetAllBooksDAL();
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bookllist;
        }

        public static Book GetBookBL(int bookid)
        {
            Book book = null;
            try
            {
                BMSDAL bmsdal = new BMSDAL();
                book = bmsdal.GetBookDAL(bookid);
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return book;
        }

        public static bool UpdateBookBL(Book book)
        {
            bool bookupdate = false;
            try 
            {
                if (ValidateBook(book))
                {
                    BMSDAL bmsdal = new BMSDAL();
                    bookupdate = bmsdal.UpdateBookDAL(book);
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bookupdate;
        }

        public static bool DeleteBookBL(int id)
        {
            bool bookdelete = false;

            try
            {
                if (id > 0)
                {
                    BMSDAL bmsdal = new BMSDAL();
                    bookdelete = bmsdal.DeleteBookDAL(id);
                }
                else
                {
                    throw new BookException("Invalid Book ID");
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bookdelete;
        }
    }
}
