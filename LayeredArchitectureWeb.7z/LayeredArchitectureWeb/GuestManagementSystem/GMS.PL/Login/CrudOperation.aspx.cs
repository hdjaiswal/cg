﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using CustomException;
using BusinessLogicLayer;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace GMS.PL
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        
       
        protected void Page_Load(object sender, EventArgs e)
        {
              
        }

        GuestValidations validationsObj = new GuestValidations();
        
                  

        Guest gObj = new Guest();

        protected void Button1_Click(object sender, EventArgs e)
        {
                 

            gObj.GuestID = Convert.ToInt32(TextBox1.Text);
            gObj.GuestName = TextBox2.Text;
            gObj.ContactNo = Convert.ToInt64(TextBox3.Text);

            bool guestAdded = validationsObj.AddGuestRecord(gObj);

           Response.Write("<script>alert('Guest Added succesfully');</script>");
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
         

            DataTable guestTable = new DataTable();
            int result = Convert.ToInt32(TextBox1.Text);
            guestTable = validationsObj.DeleteGuestRecord(result);
            Response.Write("<script>alert('Guest Deleted succesfully');</script>");
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            bool isNumber;
            int result;
            long contactNo;
            isNumber = int.TryParse(TextBox1.Text, out result);
            if (isNumber)
            {
                gObj.GuestID = result;
            }
            
            gObj.GuestName = TextBox2.Text;
            isNumber = long.TryParse(TextBox3.Text, out contactNo);
            if (isNumber)
                gObj.ContactNo = contactNo;

            bool guestUpdated = validationsObj.UpdateGuestRecord(gObj);
            Response.Write("<script>alert('Guest Updated succesfully');</script>");
        }

        protected void Show_Click(object sender, EventArgs e)
        {
        
            DataTable guestTable = new DataTable();

            guestTable = validationsObj.GetGuestAllRecord();

            GridView1.DataSource = guestTable;
            GridView1.DataBind();}

        protected void Search_Click(object sender, EventArgs e)
        {
            DataTable guestTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(TextBox1.Text, out result);
            if (isNumber)
                guestTable = validationsObj.GetGuestRecord(result);
            else
            {
                Response.Write("<script>alert('Please Enter only numbers in Guest ID Field');</script>");
                return;
            }
            GridView1.DataSource = guestTable;
            GridView1.DataBind();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            TextBox1.Text="";
            TextBox2.Text="";
            TextBox3.Text=""    ;
            TextBox1.Focus();
        }

      
    }
}