﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using CustomException;
using BusinessLogicLayer;
using System.Data.SqlClient;

namespace PresentationLayer
{
    public partial class Form1 : Form
    {
        GuestValidations validationsObj = new GuestValidations();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddGuest_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guestObj = new Guest();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtGuestID.Text, out result);
                if (isNumber)
                    guestObj.GuestID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                guestObj.GuestName = txtGuestName.Text;
                isNumber = long.TryParse(txtConatctNo.Text, out contactNo);
                if (isNumber)
                    guestObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Contact No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            
                bool guestAdded = validationsObj.AddGuestRecord(guestObj);
                if (guestAdded)
                    MessageBox.Show("Guest Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add guest record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (GuestException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DataTable guestTable=new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtGuestID.Text, out result);
            if (isNumber)
                guestTable = validationsObj.GetGuestRecord(result);
            else
            {
                MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvGuest.DataSource = guestTable;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btndisplayall_Click(object sender, EventArgs e)
        {
            DataTable guestTable = new DataTable();
           
            guestTable = validationsObj.GetGuestAllRecord();
          
            dgvGuest.DataSource = guestTable;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
            Guest guestObj = new Guest();
            DataTable guestTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtGuestID.Text, out result);
            if (isNumber)
            {
                guestTable = validationsObj.DeleteGuestRecord(result);
                MessageBox.Show("Guest Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please enter numbers in Guest ID field to Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

              
             
            dgvGuest.DataSource = guestTable;
            }
            catch (GuestException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guestObj = new Guest();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtGuestID.Text, out result);
                if (isNumber)
                {
                    guestObj.GuestID = result;
                }
                else
                {
                    MessageBox.Show("Please enter Guest ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                guestObj.GuestName = txtGuestName.Text;
                isNumber = long.TryParse(txtConatctNo.Text, out contactNo);
                if (isNumber)
                    guestObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Contact No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool guestUpdated = validationsObj.UpdateGuestRecord(guestObj);
                if (guestUpdated)
                    MessageBox.Show("Guest Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update guest record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (GuestException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtGuestID.Clear();
            txtGuestName.Clear();
            txtConatctNo.Clear();
            txtGuestID.Focus();
        }
    }
}
