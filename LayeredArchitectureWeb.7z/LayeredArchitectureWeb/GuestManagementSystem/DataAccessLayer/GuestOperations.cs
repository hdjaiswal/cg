﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Entity;
using CustomException;

namespace DataAccessLayer
{
    /// <summary>
    /// Class containing database code
    /// Author:
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class GuestOperations
    {
        SqlConnection connection;
        SqlDataReader reader;
       
        public GuestOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["GMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add customer record
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="guestObj"></param>
        /// <returns>bool</returns>
        public bool AddGuestRecord(Guest guestObj)
        {
            try
            {
                bool guestAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddGuest", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@GuestID", guestObj.GuestID);
                cmdAdd.Parameters.AddWithValue("@GuestName", guestObj.GuestName);
                cmdAdd.Parameters.AddWithValue("@ContactNo", guestObj.ContactNo);
                if (connection.State == ConnectionState.Closed)
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
               
                if (result > 0)
                    guestAdded = true;
                return guestAdded;
            }
            catch (GuestException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
        
        /// <summary>
        /// Method to Search Guest information
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No: 
        /// </summary>
        /// <param name="guestID"></param>
        /// <returns></returns>
        public DataTable GetGuestRecord(int guestID)
        {
            SqlCommand cmdGetGuest = new SqlCommand("RetrieveGuestInfo", connection);
            cmdGetGuest.CommandType = CommandType.StoredProcedure;
            cmdGetGuest.Parameters.AddWithValue("@GuestID", guestID);
            if(connection.State==ConnectionState.Closed)
                connection.Open();
            reader = cmdGetGuest.ExecuteReader();
            DataTable  guestTable = new DataTable();
            guestTable.Load(reader);
            return guestTable;
           
        }

        public DataTable GetGuestAllRecord()
        {
            SqlCommand cmdGetAllGuest = new SqlCommand("Select * from Guest", connection);
            SqlDataAdapter da = new SqlDataAdapter(cmdGetAllGuest);
           
            if (connection.State == ConnectionState.Closed)
                connection.Open();
          //  reader = cmdGetAllGuest.ExecuteReader();
            DataTable guestTable = new DataTable();
            da.Fill(guestTable);
           
            return guestTable;
            
        }

        public DataTable DeleteGuestRecord(int guestID)
        {
            SqlCommand cmdDelGuest = new SqlCommand("DeleteGuestInfo", connection);
            
               
            cmdDelGuest.CommandType = CommandType.StoredProcedure;
            cmdDelGuest.Parameters.AddWithValue("@GuestID", guestID);
          

                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdDelGuest.ExecuteReader();
                DataTable guestTable = new DataTable();
                guestTable.Load(reader);
                return guestTable;   
        }

        public bool UpdateGuestRecord(Guest guestObj)
        {


            try
            {
                bool guestUpdated = false;
                SqlCommand cmdAdd = new SqlCommand("UpdateGuest", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@GuestID", guestObj.GuestID);
                cmdAdd.Parameters.AddWithValue("@GuestName", guestObj.GuestName);
                cmdAdd.Parameters.AddWithValue("@ContactNo", guestObj.ContactNo);
                if (connection.State == ConnectionState.Closed)
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();

                if (result > 0)
                    guestUpdated = true;
                return guestUpdated;
            }
            catch (GuestException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
               
        }
           
    }
}
