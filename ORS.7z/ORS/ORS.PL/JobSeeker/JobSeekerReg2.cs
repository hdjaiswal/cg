﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class JobSeekerReg2 : Form
    {
        public JobSeekerReg2()
        {
            InitializeComponent();
        }

        private void btnJsReg2_Click(object sender, EventArgs e)
        {
            JobSeekerReg3 frm = new JobSeekerReg3();
            frm.Show();
            this.Hide();
        }
    }
}
