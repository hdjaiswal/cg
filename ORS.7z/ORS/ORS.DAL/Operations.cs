﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLib;


namespace ORS.DAL
{
    public class Operations
    {
        SqlConnection connection;
        SqlDataReader reader;

         public Operations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

         public bool AddJobSeekerRecord(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("AddJobseekers", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", jobj.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", jobj.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", jobj.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", jobj.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", jobj.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", jobj.JPassword);
              //   cmdAdd.Parameters.AddWithValue("@", jobj.JCnfPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", jobj.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", jobj.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", jobj.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", jobj.JMaritalStatus);
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }
       
    }
}
