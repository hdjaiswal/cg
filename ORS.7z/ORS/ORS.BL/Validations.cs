﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;

namespace ORS.BL
{
    public class Validations
    {
        Operations operationObj = new Operations();
        public bool ValidateJobSeekerRecord(ORSEntity jobj)
        {
            bool validJobSeekerRecord = true;
            StringBuilder sb = new StringBuilder();
            if (jobj.JFirstName.ToString().Length == 0)
            {
                validJobSeekerRecord = false;
                sb.Append(Environment.NewLine + "Job Seekar Name is required.");
            }

            if (validJobSeekerRecord == false)
                throw new CustomException(sb.ToString());
            return validJobSeekerRecord;
        }

        public bool AddJobSeekerRecord(ORSEntity jobj)
        {
            bool jsAdded = false;
            if (ValidateJobSeekerRecord(jobj))
                jsAdded = operationObj.AddJobSeekerRecord(jobj);
            return jsAdded;
        }
    }
}
