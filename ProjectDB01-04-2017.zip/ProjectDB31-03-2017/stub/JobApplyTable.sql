Create table ORSGroup6.JobDetails
(
	JobId int identity(1,1) Primary Key,
	CompanyName varchar(20) ,
	Post varchar(20),
	Vacancies int,
	PostedDate datetime,
	LastDate datetime,
	CompanyDescription nvarchar(2000),
	Package Decimal,
	JobLocation varchar(20),
	Experience varchar(20),
	EmployeeID int Foreign key references ORSGroup6.EmployeeDetails(EmployeeID),
	)
select * from ORSGroup6.JobDetails
select * from ORSGroup6.AppliedJobs


Drop table ORSGroup6.JobDetails
Drop table ORSGroup6.AppliedJobs
Create table ORSGroup6.AppliedJobs
(
	JobAppliedId int identity(1,1) Primary key,
	JobId int Foreign key references ORSGroup6.JobDetails(JobId),
	EmployeeId  int ,
	JobSeekerId  int Foreign key references ORSGroup6.JobseekersPersonalDetails(JobSeekerID),
	)

create Procedure ORSGroup6.AddJobs
(
@CompanyName varchar(20) ,
@Post varchar(20),
@Vacancies int,
@PostedDate datetime,
@LastDate datetime,
@CompanyDescription nvarchar(2000),
@Package Decimal,
@JobLocation varchar(20),
@Experience varchar(20),
@EmployeeID int
)
AS
BEGIN
Insert into ORSGroup6.JobDetails Values(@CompanyName,@Post,@Vacancies,@PostedDate,@LastDate,@CompanyDescription,@Package,@JobLocation,@Experience,@EmployeeID);
END

EXEC AddJobs 'syntel','manager',3,'02/02/2010','03/03/2016','greatcomapnny',20.02,'mumbai','2-3',1

EXEC AddJobs 'Capgemini','Software Engg',3,'02/23/2015','12/12/2015','Good Company',2.6,'Delhi','0-2',2 

Select * from ORSGroup6.JobDetails 
select * from ORSGroup6.AppliedJobs
DROP table ORSGroup6.JobDetails 
Drop table ORSGroup6.AppliedJobs

Drop Procedure ORSGroup6.ApplyJOBS

alter Procedure ORSGroup6.ApplyJobs
(
@JobId int,
@JobSeekerId int
)
AS 
BEGIN
Declare @EmployeeId int
SET @EmployeeID =(Select EmployeeID From ORSGroup6.JobDetails  where JobId=@JobId )
Insert into ORSGroup6.AppliedJobs values(@JobId,@EmployeeId,@JobSeekerId)
END

EXEC ORSGroup6.ApplyJobs 1,1


Create Procedure ORSGroup6.ViewjobsByEmployee
(
@EmployeeID int
)
AS 
BEGIN 
SELECT  * FROM  ORSGroup6.JobDetails where(EmployeeID=@EmployeeID)
END 
EXEC ORSGroup6.ViewjobsByEmployee 1

