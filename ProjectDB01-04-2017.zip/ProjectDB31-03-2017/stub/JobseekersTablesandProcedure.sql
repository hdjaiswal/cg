-- JobSeekers Table
-- JobSekkers Login Table

create schema ORSGroup6;

create table ORSGroup6.JobseekersLogin
(
LoginID int identity(1,1) PRIMARY KEY,
EmailAddress varchar(50)UNIQUE,
Password varchar(20),
jobseekerID int 
)

Drop table  ORSGroup6.JobseekersLogin
drop table ORSGroup6.JobseekersLogin
Drop table ORSGroup6.JobseekersPersonalDetails
Drop Table ORSGroup6.JobSeekerProfessionalDetails
Drop table ORSGroup6.JobseekersQualificationDetails 
--Jobseekers PersonalDetails 
 create table  ORSGroup6.JobseekersPersonalDetails
 (
JobSeekerID int identity(1,1) PRIMARY KEY,
FirstName Varchar(20),
LastName Varchar(20),
MiddleName varchar(20),
ContactNo bigint,
EmailAddress varchar(50)UNIQUE,
Gender varchar(10),
MarraigeStatus varchar(10),
JobSeekersAddress varchar(50),
DOB DateTime
 )


 drop table ORSGroup6.JobseekersPersonalDetails;
 --Jonseekers Image table
 Create Table ORSGroup6.ProfilePhoto
(
	imageID int Identity(0,1) Primary Key,
	images image null,
	JobSeekerID int
	)

	drop table  ORSGroup6.ProfilePhoto;
 --Jobseekers Professtional Details 
 Create Table ORSGroup6.JobSeekerProfessionalDetails
 (
JobSeekerID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID) Unique,
CurrentDesignation varchar(20),
PrimarySkills varchar(50),
SecondarySkills varchar(50),
TrainingAttended varchar(30),
Designation varchar(20),
Location varchar(30),
Experience varchar(20),
 )
Drop table  ORSGroup6.JobSeekerProfessionalDetails

 select * from ORSGroup6.JobseekersPersonalDetails
 select * from ORSGroup6.JobseekersLogin
 
 --Table for Job seekers Qualification 
 Create Table  ORSGroup6.JobseekersQualificationDetails 
 (
 QualificationID int identity(1,1) Primary key,
 Degree Varchar(20),
 Branch Varchar(20),
 Passingyear int,
 Percentage Decimal,
 UniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )

 Truncate table ORSGroup6.JobseekersPersonalDetails

 Drop table ORSGroup6.JobseekersQualificationDetails 
 -------------------------------------------------------------------------------------------------------------------------------------
-- Procedure to Insert New Jobseeker
 Alter Procedure ORSGroup6.AddJobseekers
(
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@EmailAddress varchar(50),
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB DateTime,
@Password varchar(20)
)
AS
BEGIN
SET NOCOUNT ON;
insert into ORSGroup6.JobseekersPersonalDetails Values(@FirstName,@LastName,@MiddleName,@ContactNO,@EmailAddress,@Gender,@MarraigeStatus,@JobSeekersAddress,@DOB)
Insert into ORSGroup6.JobseekersLogin Values(@EmailAddress,@Password,scope_identity())
END
select JobSeekerID from ORSGroup6.JobseekersPersonalDetails

 EXEC AddJobseekers 'Riya','sharma','rajesh',7896547859,'riya@gmail.com','Male','Single','Mumbai','02/02/1964','Raj@123'
 EXEC AddJobseekers 'Om','Rao','Rakshit',7896547859,'OM@gmail.com','Male','Single','Chennai','04/21/1964','OM@123'
 EXEC AddJobseekers 'sangita','Dutt','Ramesh',7896547859,'sangita@gmail.com','Female','Single','Pune','02/02/1964','Raj@123'
 EXEC AddJobseekers 'sunita','Dange','Ram',7896547859,'sunita@gmail.com','Female','Single','Delhi','12/24/1999','sunita@123'
  EXEC AddJobseekers 'Sheetal','Dange','Ram',7896547859,'sheetal@gmail.com','Female','Single','Delhi','12/24/1999','sheetal@123'
   EXEC AddJobseekers 'Shee','Dancce','Ram',7896547859,'Shi@gmail.com','Female','Single','Delhi','12/24/1999','sheetal@123'
 
 
 select * from ORSGroup6.JobseekersPersonalDetails;
 
 EXEC EmployeeVerification 'sunita@gmail.com','sun@123'
Drop procedure AddJobseekers

 --Procedure to Check for jobseekersValidation

 Alter Procedure JobSeekerVerification
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
      
      SELECT EmailAddress,Password
      FROM ORSGroup6.JobseekersLogin WHERE EmailAddress = @EmailAddress AND Password = @Password   
END

select * from ORSGroup6.JobseekersLogin;

Exec JobSeekerVerification 'riya@gmail.com','Raj@123';

--Procedure to add Job seekers Proffessional Details 
create Procedure AddProfessionaDetails
(
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20)
)
AS 
Begin
Declare @jobseekerId int 
SET NOCOUNT ON;
IF NOT EXISTS (Select * from ORSGroup6.JobSeekerProfessionalDetails where jobseekerId= @jobseekerId)
BEGIN
Insert into ORSGroup6.JobSeekerProfessionalDetails Values(@jobseekerId,@CurrentDesignation,@PrimarySkills,@SecondarySkills,@TrainingAttended,@Designation,@Location,@Experience)
END
ELSE
SELECT 23
END 


EXEC AddProfessionaDetailsANDphoto 1,'Manager','Java','DOTNET','Andriod','Developer','Mumbai','2-3'
EXEC AddProfessionaDetailsANDphoto 2,'Anayst','Oracle','HTML','DOTNET','TeamLead','chennai','0-3'

Drop table ORSGroup6.JobSeekerProfessionalDetails

Select * from ORSGroup6.JobSeekerProfessionalDetails

select * from ORSGroup6.JobseekersQualificationDetails

 select * from ORSGroup6.JobseekersPersonalDetails;
(
-- Procedure to Add Job sekkers QulaificationDetails 
alter Procedure JobseekersQualificationDetails
(
 @Degree Varchar(20),
 @Branch Varchar(20),
 @Passingyear int,
 @Percentage Decimal,
 @UniversityName varchar(20),
 @JobSeekerID int
 )
AS 
Begin
SET NOCOUNT ON;
BEGIN

Insert into ORSGroup6.JobseekersQualificationDetails Values(@Degree,@Branch,@Passingyear,@Percentage,@UniversityName,@JobSeekerID)
END
END

EXEC JobseekersQualificationDetails 'BE','computers',2014,66.64,'Mumbai'
EXEC JobseekersQualificationDetails 'SSC',Null,2010,78.24,'Mumbai'
EXEC JobseekersQualificationDetails 'HSC','',2012,78.65,'Mumbai',3

select * from ORSGroup6.JobseekersQualificationDetails;



-- Create Procedure to display data Based on JobseekersId 
Create Procedure DisplayQualification
(
@JobSeeker int
)
AS 
BEGIN 
Select * from ORSGroup6.JobseekersQualificationDetails where JobseekersID = @JobSeeker
END
EXEC DisplayQualification 3

-- create Procedure for Update JobseekersPersonalDetails
Create Procedure UpdatePersonalDetails 
(
@JobSeekerId int,
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB Datetime)
AS 
UPDATE ORSGroup6.JobseekersPersonalDetails
SET
FirstName=@FirstName ,
LastName=@LastName ,
MiddleName=@MiddleName ,
ContactNo=@ContactNo,
Gender= @Gender ,
MarraigeStatus=@MarraigeStatus,
JobSeekersAddress=@JobSeekersAddress,
DOB=@DOB
Where JobSeekerID=@JobSeekerId

drop procedure UpdatePersonalDetails ; 

Exec UpdatePersonalDetails 1,'pranita','Shete','rajesh',1236547896,'Female','Married','mumbai','06/24/1999'
-- Procedure to Update Proffessional Details 
Alter Procedure UpdateProfesionalDetails
(
@jobseekerId int,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20))
As
UPDATE ORSGroup6.JobSeekerProfessionalDetails
SET 
CurrentDesignation=@CurrentDesignation,
PrimarySkills=@PrimarySkills,
SecondarySkills=@SecondarySkills,
TrainingAttended=@TrainingAttended,
Designation=@Designation,
Location=@Location,
Experience=@Experience
where JobSeekerID= @jobseekerId;

drop procedure UpdateProfesionalDetails;

EXEC UpdateProfesionalDetails 1 ,'SoftwareEngineer','DOTNET','HTML','DOTNET','TESTER','DELHI','3-4'


























Drop Table ORSGroup6.JobseekersPersonalDetails
Drop Table ORSGroup6.JobSeekerProfessionalDetails