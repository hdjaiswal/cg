Create table ORSGroup6.JobDetails
(
	JobId int identity(1,1) Primary Key,
	CompanyName varchar(20) ,
	Post varchar(20),
	Vacancies int,
	PostedDate datetime,
	LastDate datetime,
	CompanyDescription nvarchar(2000),
	Package Decimal,
	JobLocation varchar(20),
	Experience varchar(20),
	EmployeeID int Foreign key references ORSGroup6.EmployeeDetails(EmployeeID),
	)
select * from ORSGroup6.JobDetails
Drop table ORSGroup6.JobDetails
Drop table ORSGroup6.AppliedJobs
Create table ORSGroup6.AppliedJobs
(
	JobAppliedId int identity(1,1) Primary key,
	JobId int Foreign key references ORSGroup6.JobDetails(JobId),
	EmployeeId  int ,
	JobSeekerId  int Foreign key references ORSGroup6.JobseekersPersonalDetails(JobSeekerID),
	)

create Procedure AddJobs
(
@CompanyName varchar(20) ,
@Post varchar(20),
@Vacancies int,
@PostedDate datetime,
@LastDate datetime,
@CompanyDescription nvarchar(2000),
@Package Decimal,
@JobLocation varchar(20),
@Experience varchar(20),
@EmployeeID int
)
AS
BEGIN
Insert into ORSGroup6.JobDetails Values(@CompanyName,@Post,@Vacancies,@PostedDate,@LastDate,@CompanyDescription,@Package,@JobLocation,@Experience,@EmployeeID);
END

EXEC AddJobs 'syntel','manager',3,'02/02/2010','03/03/2016','greatcomapnny',20.02,'mumbai','2-3',1


