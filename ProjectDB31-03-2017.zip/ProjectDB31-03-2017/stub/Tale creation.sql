--Tables associated with  Employees
using 
--Login detailsof Employee
CREATE TABLE ORSGRP6.LoginDetails_ORSGRP6

(
LoginID int identity(1,1),
UserName varchar(20),
Password varchar(20),
EmployeeID int 
)

drop table [ORSGRP6].[LoginDetails_ORSGRP6]
--Personal details of Employee
Create Table ORSGRP6.EmployeeDetails_ORSGRP6
(
EmployeeID int identity(1,1) Primary key,
FirstName varchar(20),
LastName varchar(20),
CompanyID int,
Designation varchar(20),
Location varchar(20),
ContactNO bigint,
EmailAddress varchar(20)
);

select * from [ORSGRP6].[EmployeeDetails_ORSGRP6]
select * from [ORSGRP6].[LoginDetails_ORSGRP6]

Drop table [ORSGRP6].[EmployeeDetails_ORSGRP6]
Drop table  [ORSGRP6].[LoginDetails_ORSGRP6]


--Procedure to Add New Employee
Create Procedure AddUser
(
@FirstName varchar(20),
@LastName varchar(20),
@CompanyID int,
@Designation varchar(20),
@Location varchar(20),
@ContactNO bigint,
@EmailAddress varchar(20),
@UserName varchar(20),
@Password varchar(20))
AS
insert into [ORSGRP6].[EmployeeDetails_ORSGRP6]Values(@FirstName,@LastName,@CompanyID,@Designation,@Location,@ContactNO,@EmailAddress)
Insert into [ORSGRP6].[LoginDetails_ORSGRP6]Values(@UserName,@Password,scope_identity())

Drop Procedure  AddUser 

EXEC AddUser 'RAJESH','sharma',12,'ER','Mumbai',78965458957,'RAj@gmail.com','rajsharma','raj@123'

--Procedure to check employees Valid credentials 

CREATE PROCEDURE validateEmployee
      @Username NVARCHAR(20),
      @Password NVARCHAR(20)
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @empId INT
     
      SELECT @empId = EmployeeID
      FROM [ORSGRP6].[LoginDetails_ORSGRP6] WHERE UserName = @Username AND Password = @Password
     
      IF @empId IS NOT NULL
      BEGIN
            Select * from [ORSGRP6].[EmployeeDetails_ORSGRP6] Where [EmployeeID]=@empId
           END
           
      ELSE
      BEGIN
            SELECT -1 -- User invalid.
      END
END

EXEC validateEmployee 'rajsharma','raj@123'

-- Procedure To insert into Job Details
 