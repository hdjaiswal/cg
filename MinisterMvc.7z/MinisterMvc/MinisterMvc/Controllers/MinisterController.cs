﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MinisterMvc.Models;
namespace MinisterMvc.Controllers
{
    public class MinisterController : Controller
    {
        //
        // GET: /Minister/

        Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();
        public ActionResult Index()
        {
            return View(context.minister_12182);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(minister_12182 mns)
        {
            if (ModelState.IsValid)
            {
                context.minister_12182.Add(mns);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(mns);
            }
        }

        public ActionResult Update(int id)
        {
            return View(context.minister_12182.Find(id));
        }

        [HttpPost]
        public ActionResult Update(minister_12182 mnsj)
        {

            if (ModelState.IsValid)
            {
                minister_12182 mnss = new minister_12182();
                mnss = context.minister_12182.First(e => e.id == mnsj.id);
                mnss.name = mnsj.name;
               
                context.SaveChanges();

                return RedirectToAction("index");
            }
            else
            {
                return View();
            }

        }

        public ActionResult Display()
        {
            minister_12182 tran = new minister_12182();

            var searchminister = (from eq in context.minister_12182 
                                  where eq.id == 1832
                                  select eq).First();
            searchminister.name = "Diksha";
            context.SaveChanges();
         
            return View(searchminister);
        }
        


        //  public ActionResult Index()
        //{
        //    return View();
        //}
        public ActionResult DeleteRecord()
                {
                     minister_12182 plp = new minister_12182();

                    var query = from a in context.minister_12182
                                where a.id == 123
                                select a;

                    foreach (var item in query.ToList())
                    {
                        context.minister_12182.Remove(item);
                        context.SaveChanges();
                    }
                    return View(query);
                }

            }
        }
        


    


