﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;
using CMS.Exception;
using CMS.DAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;


namespace CMS.BLL
{
    public class CustomerValidation
    {
        CustomerOperation coperation = new CustomerOperation();
        public bool ValidateCustomer(Customer cst)
        {
            StringBuilder sb = new StringBuilder();
            bool customerValidated = true;
            if (cst.CustomerID.ToString() == String.Empty)
            {
                customerValidated = false;
                sb.Append("CustomerID is Required\n");
            }
            if (cst.Name == String.Empty)
            {
                customerValidated = false;
                sb.Append("customer Name cannot be Empty");
            }
            else if (!Regex.IsMatch(cst.Name, @"^[a-zA-Z ]+$"))
            {
                customerValidated = false;
                sb.Append("customer Name Sholud have only character");
            }
            if (cst.Address == String.Empty)
            {
                customerValidated = false;
                sb.Append("adress Cannot BE Empty");
            }
            if (cst.City == String.Empty)
            {
                customerValidated = false;
                sb.Append("City cannot be empty");
            }

            if (cst.Landmark == String.Empty)
            {
                customerValidated = false;
                sb.Append("lndmark Cannot Be Empty");
            }
            if (cst.Pincode.ToString() == String.Empty)
            {
                customerValidated = false;
                sb.Append("Customer pin is Required\n");
            }
            if (cst.ContactNo.ToString() == String.Empty)
            {
                customerValidated = false;
                sb.Append("Customer num is Required\n");
            }
            if (cst.EmailID == String.Empty)
            {
                customerValidated = false;
                sb.Append("EMAIL IDCannot Be Empty");
            }

            if (customerValidated == false)
            {
                throw new CustomerException(sb.ToString());
            }
            return customerValidated;
        }
        public bool AddCustomer(Customer cst)
        {
            bool customerAdded = false;
            try
            {
                if (ValidateCustomer(cst))
                {
                    customerAdded = coperation.AddCustomer(cst);
                }
                return customerAdded;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        
        }


        public DataTable DisplayCustomer()
        {
            DataTable table = new DataTable();
            try
            {
                table = coperation.DislpayCustomer();
                return table;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
           
        }
    }
}