﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CMS.Entity;
using CMS.Exception;


namespace CMS.DAL
{
    public class CustomerOperation
    {
        SqlConnection connection;
        SqlCommand cmd;
        SqlDataReader reader;
        DataSet ds;
        public CustomerOperation()
        {
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Customer"].ConnectionString);
        }
        public bool AddCustomer(Customer cst)
        {
           
            try
            {
                bool customerAdded = false;
                cmd = new SqlCommand("AddCustomr_DN121701", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustomerID", cst.CustomerID);
                cmd.Parameters.AddWithValue("@Name", cst.Name);
                cmd.Parameters.AddWithValue("@Address", cst.Address);
                cmd.Parameters.AddWithValue("@City", cst.City);
                cmd.Parameters.AddWithValue("@Landmark", cst.Landmark);
                cmd.Parameters.AddWithValue("@Pincode", cst.Pincode);
                cmd.Parameters.AddWithValue("@ContactNo", cst.ContactNo);
                cmd.Parameters.AddWithValue("@EmailID", cst.EmailID);
                if (connection.State == ConnectionState.Closed)
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    customerAdded = true;
                }
                return customerAdded;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            
        }

        public DataTable DislpayCustomer()
        {
          
            try
            {
                cmd = new SqlCommand("DisplayAllCustomrInfo_DN121701", connection);

                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                return table;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
        
        }
    }
}
