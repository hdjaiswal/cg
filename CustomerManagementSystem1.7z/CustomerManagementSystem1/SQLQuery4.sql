CREATE TABLE STUDENTS_12170011 (  
ID INT                           NOT NULL,  
NAME VARCHAR (20) NOT NULL,  
AGE INT                         NOT NULL,  
ADDRESS CHAR (25),  
PRIMARY KEY (ID)  
);  
