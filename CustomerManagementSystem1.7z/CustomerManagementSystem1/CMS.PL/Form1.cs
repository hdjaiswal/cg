﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CMS.BLL;
using System.Data.SqlClient;
using CMS.Exception;
using CMS.Entity;

namespace CMS.PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        CustomerValidation cvalidate = new CustomerValidation();


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) //add
        {
            try
            {
                bool isNumber;
                int result;
                Customer cst = new Customer();
                isNumber = int.TryParse(textBox1.Text, out result);
                if (isNumber)
                    cst.CustomerID = result;
                else
                {
                    MessageBox.Show("Cst ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                cst.Name = txtName.Text;
                cst.Address = txtAddress.Text;
                cst.City = txtCity.Text;
                cst.Landmark = txtLandmark.Text;
                isNumber = int.TryParse(txtPincode.Text, out result);
                if (isNumber)
                    cst.Pincode = result;
                else
                {
                    MessageBox.Show("pincode must be Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                isNumber = int.TryParse(txtContactNo.Text, out result);
                if (isNumber)
                    cst.ContactNo = result;
                else
                {
                    MessageBox.Show("Student cno must be Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                cst.EmailID = txtEmailID.Text;
                bool flag = cvalidate.AddCustomer(cst);
                if (flag == true)
                {
                    MessageBox.Show("cst  Added");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)  //display
        {
            try
            {
                DataTable table = new DataTable();
                table = cvalidate.DisplayCustomer();
                dataGridView1.DataSource = table;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }                                     
        
    }
}
