﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebAppliation_1.MyRef;

namespace WebAppliation_1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("<h2>" + DateTime.Now.ToString() + "</h2>");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            StudentServiceSoapClient obj = new StudentServiceSoapClient();
            GridView1.DataSource = obj.FetchAllStudents();
            Page.DataBind();
        }
    }
}