﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;

namespace DAL_WebService
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class StudentService : System.Web.Services.WebService
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        [WebMethod]
        public DataTable FetchAllStudents()
        {
            con = new SqlConnection();
            con.ConnectionString = @"server=ndamssql\sqlilearn;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser";
            //Initailize the object
            adap = new SqlDataAdapter();
            adap.SelectCommand = new SqlCommand();
            adap.SelectCommand.CommandText = "Select * from Students";
            adap.SelectCommand.Connection = con;
            DataSet ds = new DataSet();
            adap.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            adap.Fill(ds, "Stud");

            return ds.Tables["Stud"];
        }
    }
}