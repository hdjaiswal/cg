﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using DBApproach_MVC_Mod4_121657.Models;

namespace DBApproach_MVC_Mod4_121657.Controllers
{
    public class BookCabController : Controller
    {
        //
        // GET: /BookCab/
        Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DeleteUser()
        {
            return View();

        }

        [HttpPost]
        public ActionResult DeleteUser(int BookingID)
        {
            BookCab_121657 BookCab = new BookCab_121657();
            if (ModelState.IsValid)
            {
                BookCab = context.BookCab_121657.Find(BookingID);
                context.BookCab_121657.Remove(BookCab);
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                return View(BookCab);
            }

        }
    }
}
