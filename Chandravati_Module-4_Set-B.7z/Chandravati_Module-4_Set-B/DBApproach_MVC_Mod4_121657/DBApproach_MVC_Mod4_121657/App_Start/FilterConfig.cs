﻿using System.Web;
using System.Web.Mvc;

namespace DBApproach_MVC_Mod4_121657
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}