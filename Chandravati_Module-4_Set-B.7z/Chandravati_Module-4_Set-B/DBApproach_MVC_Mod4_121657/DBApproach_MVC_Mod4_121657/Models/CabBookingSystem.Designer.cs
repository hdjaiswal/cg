﻿// Default code generation is disabled for model 'D:\Chandravati(dotnet batch)\Chandravati_Module-4_Set-B\DBApproach_MVC_Mod4_121657\DBApproach_MVC_Mod4_121657\Models\CabBookingSystem.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.