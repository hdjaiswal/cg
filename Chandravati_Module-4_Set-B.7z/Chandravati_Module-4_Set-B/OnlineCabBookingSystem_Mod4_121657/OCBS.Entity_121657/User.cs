﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCBS.Entity_121657
{
    /// <summary>
    ///  /// <summary>
    /// name:Chandravati mahule
    /// employee id: 121657
    /// description : Entity class for Booking cab  online 
    /// </summary>
    /// </summary>
    public class User
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
