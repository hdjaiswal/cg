﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCBS.Entity_121657
{
    /// <summary>
    /// name:Chandravati mahule
    /// employee id: 121657
    /// description : Entity class for Booking cab  online 
    /// </summary>
    public class BookCab
    {

        public int BookCabID { get; set; }
        public string SourceName { get; set; }
        public string DestName { get; set; }
        public DateTime PickDate { get; set; }
        public string PickTime { get; set; }
    }
}
