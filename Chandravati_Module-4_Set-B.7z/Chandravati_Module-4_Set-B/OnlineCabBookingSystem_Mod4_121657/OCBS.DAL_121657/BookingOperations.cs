﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OCBS.Entity_121657;
using OCBS.Exception_121657;

namespace OCBS.DAL_121657
{
    public class BookingOperations
    {
        public static int InsertCustomer(BookCab bkc)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ProcInsertDetails_121657";

                cmd.Parameters.AddWithValue("@sourceName", bkc.SourceName);
                cmd.Parameters.AddWithValue("@destName", bkc.DestName);
                cmd.Parameters.AddWithValue("@picKDate", bkc.PickDate);
                cmd.Parameters.AddWithValue("@pickTime", bkc.PickTime);
               

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteCustomer(int bkcabID)
        {
            int recordAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ProcDeleteDetails_121657";
                cmd.Parameters.AddWithValue("@bookingID", bkcabID);

                cmd.Connection.Open();
                recordAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordAffected;
        }


        public static DataTable DisplayCustomer()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ProcDisplayDetails_121657";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new BookingException("Employee Data not Available");
                }
                cmd.Connection.Close();
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dt;
        }




    }
}
