﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCBS.Exception_121657
{
    public class BookingException:ApplicationException
    {
        public BookingException()
            : base()
        { }

        public BookingException(string message)
            : base(message)
        { }
    }
}
