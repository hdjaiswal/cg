﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.DAL_121657;

namespace OCBS.BL_121657
{
    public class UserValidation
    {
        public static string ValidateUser(User user)
        {
            string userName = null;

            try
            {
                userName =UserOperation.ValidateLogin(user);
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
