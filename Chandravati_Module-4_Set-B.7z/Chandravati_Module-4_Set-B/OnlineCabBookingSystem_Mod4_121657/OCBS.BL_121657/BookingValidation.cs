﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.DAL_121657;

namespace OCBS.BL_121657
{
    public class BookingValidation
    {
        public static int InsertCustomer(BookCab bkc)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = BookingOperations.InsertCustomer(bkc);
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteCustomer(int bkcabID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = BookingOperations.DeleteCustomer(bkcabID);
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static DataTable DisplayCustomer()
        {
            DataTable dt = null;

            try
            {
                dt = BookingOperations.DisplayCustomer();
            }
            catch (BookingException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dt;
        }


    }
}
