﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.BL_121657;

namespace OCBS.PL_121657
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = "Welcome " + Session["user"].ToString();
        }

        protected void btnLocalCab_Click(object sender, EventArgs e)
        {
           
           
            Response.Redirect("InsertCustomer.aspx");
        }
    }
}