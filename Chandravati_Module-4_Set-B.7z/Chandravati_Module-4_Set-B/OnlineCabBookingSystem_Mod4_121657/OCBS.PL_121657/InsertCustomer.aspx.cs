﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.BL_121657;

namespace OCBS.PL_121657
{
    public partial class InsertCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                BookCab bkc = new BookCab();
                bkc.SourceName = ddSource.SelectedItem.Text;
                bkc.DestName = ddDestination.SelectedItem.Text;
                bkc.PickDate = Convert.ToDateTime(txtDate.Text);
                bkc.PickTime = TxtTime.Text;
               
                int recordsAffected = BookingValidation.InsertCustomer(bkc);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Cab booked successfully')</script>");
                }
                else
                {
                    throw new BookingException("Sorry we cannot book the cab at this moment ");
                }
            }
            catch (BookingException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}