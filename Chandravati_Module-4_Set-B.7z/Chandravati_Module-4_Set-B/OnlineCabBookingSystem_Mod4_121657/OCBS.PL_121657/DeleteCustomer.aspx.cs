﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.BL_121657;
namespace OCBS.PL_121657
{
    public partial class DeleteCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lbnUser.Text = "Welcome " + Session["user"];
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int bkcabID = Convert.ToInt32(txtCabID.Text);
                int recordsAffected = BookingValidation.DeleteCustomer(bkcabID);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('booking Deleted successfully')</script>");
                }
                else
                {
                    throw new BookingException("Booking NOT Deleted");
                }
            }
            catch (BookingException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}