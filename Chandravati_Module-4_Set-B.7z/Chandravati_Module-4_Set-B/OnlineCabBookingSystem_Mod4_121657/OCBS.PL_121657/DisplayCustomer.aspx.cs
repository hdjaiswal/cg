﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OCBS.Entity_121657;
using OCBS.Exception_121657;
using OCBS.BL_121657;
using System.Data;


namespace OCBS.PL_121657
{
    public partial class DisplayCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;

                try
                {
                    DataTable dt = BookingValidation.DisplayCustomer();
                    if (dt.Rows.Count > 0)
                    {
                        gvCustomer.DataSource = dt;
                        gvCustomer.DataBind();
                    }
                    else
                        throw new BookingException("Employee Data not Available");
                }
                catch (BookingException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }
    }
}