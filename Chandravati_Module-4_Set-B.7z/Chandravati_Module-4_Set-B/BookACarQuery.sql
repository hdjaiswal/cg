
--Created table to Fill a Form ( Book a Cab)
Create Table BookCab_121657
(
	BookingID int Primary Key identity(1,1),
	SourceName nvarchar(30),
	DestName nvarchar(30),
	PicKDate Datetime ,
	PickTime nvarchar(25)
)

Drop Table BookCab_121657
Select * from BookCab_121657
 


--Procedure to insert cab details
CREATE PROC ProcInsertDetails_121657
(
	
	@sourceName nvarchar(30),
	@destName nvarchar(30),
	@picKDate Datetime ,
	@pickTime time
	
)
AS
BEGIN
	INSERT INTO BookCab_121657(SourceName, DestName, PicKDate, PickTime)
	VALUES (@sourceName, @destName, @picKDate, @pickTime)
END
GO

Drop proc ProcInsertDetails_121657


--Procedure to Update the Cab booking details
CREATE PROC ProcUpdateDetails_121657
(
	@bookingID int ,
	@sourceName nvarchar(30),
	@destName nvarchar(30),
	@picKDate Datetime ,
	@pickTime time
)
AS
BEGIN
	UPDATE BookCab_121657
	SET SourceName=@sourceName ,
		DestName  =@destName  ,
		PicKDate  =@picKDate  ,
		PickTime  =@pickTime  
	WHERE BookingID = @bookingID
END

GO

--Create Procedure To delete Booked deatils
CREATE PROC ProcDeleteDetails_121657
(
	@bookingID	INT
)
AS
BEGIN
	DELETE FROM BookCab_121657 WHERE BookingID = @bookingID
END

GO

--Create Procedure To Display Booked deatils
CREATE PROC ProcDisplayDetails_121657
AS
BEGIN
	SELECT * FROM BookCab_121657
END
GO

Drop Proc ProcDelDetails_121657


--Create table for user login
CREATE TABLE LoginUser_121657
(
	UserName	VARCHAR(10),
	Password	VARCHAR(10)
)
INSERT INTO LoginUser_121657 (UserName, Password)
VALUES ('admin', 'admin')
GO

drop table LoginUser_121657

--Create Procedure to validate user through login id and password
CREATE PROC ValidateLogin_121657
(
	@User	VARCHAR(10),
	@Password VARCHAR(10)
)
AS
BEGIN
	SELECT UserName FROM LoginUser_121657 
	WHERE UserName = @User AND Password = @Password
END

INSERT INTO BookCab_121657 Values( 'Pune', 'Mumbai', '04/22/2017', '06:45 AM')
INSERT INTO BookCab_121657 Values( 'Mumbai', 'Chennai', '04/2/2017', '07:45 AM')
INSERT INTO BookCab_121657 Values( 'Pune', 'Mumbai', '04/23/2017', '08:45 AM')
INSERT INTO BookCab_121657 Values( 'Pune', 'Mumbai', '04/5/2017', '09:45 AM')
INSERT INTO BookCab_121657 Values( 'Pune', 'Mumbai', '06/15/2015', '09:45 AM')
INSERT INTO BookCab_121657 Values( 'Pune', 'Mumbai', '06/15/2015', '09:45 AM')

select * from BookCab_121657