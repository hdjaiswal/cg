CREATE TABLE [TestTable]
(
         [ID] [int] IDENTITY(1,1) NOT NULL,
         [FileName] [nvarchar](15) NOT NULL,
         [Extension] [nvarchar](5) NOT NULL,
         [Content] [image] NULL
)




Create Table ORSGROUP6.FileUpload
(
	FileID int identity(1,1) Primary Key,
	FiName nvarchar(35) not null,
	FullPath nvarchar(1000) not null,
	JobSeekerID int  
)

select * from ORSGROUP6.FileUpload

Drop table ORSGROUP6.FileUpload

Create Procedure ORSGROUP6.ProcStoreFile
(
@filename nvarchar(35),
@fullpath nvarchar(1000),
@jobseekersID  int
) 

As
insert into  ORSGroup6.FileUpload(FiName,FullPath,JobSeekerID)
values(@filename,@fullpath,@jobseekersID)
GO

alter  procedure ORSGroup6.ProcGetFile
(@jobseekersID int)
As  
BEGIN
Declare  @fullpath nvarchar(1000)
if EXISTS (Select * from  ORSGROUP6.FileUpload where JobSeekerID=@jobseekersID)  
select FullPath from ORSGroup6.FileUpload where JobSeekerID=@jobseekersID
Else
select FullPath from ORSGroup6.FileUpload  where JobSeekerID=0
END
EXec ORSGroup6.ProcGetFile 

Drop procedure ORSGroup6.ProcStoreFile











