﻿namespace ProjectNew
{
    partial class EmployerRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployerRegistration));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnERSubmit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEFName = new System.Windows.Forms.TextBox();
            this.txtELNmae = new System.Windows.Forms.TextBox();
            this.txtEEmailAdd = new System.Windows.Forms.TextBox();
            this.txtEContactNo = new System.Windows.Forms.TextBox();
            this.txtEPassword = new System.Windows.Forms.TextBox();
            this.txtEConfirmPass = new System.Windows.Forms.TextBox();
            this.txtECName = new System.Windows.Forms.TextBox();
            this.txtEdesignation = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtELocation = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(408, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(408, 369);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Location";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(408, 478);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(407, 604);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 24);
            this.label8.TabIndex = 19;
            this.label8.Text = "Confirm Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(408, 541);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 24);
            this.label9.TabIndex = 20;
            this.label9.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(407, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 24);
            this.label6.TabIndex = 21;
            this.label6.Text = "Company Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(408, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 24);
            this.label7.TabIndex = 22;
            this.label7.Text = "Designation";
            // 
            // btnERSubmit
            // 
            this.btnERSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnERSubmit.Location = new System.Drawing.Point(527, 666);
            this.btnERSubmit.Name = "btnERSubmit";
            this.btnERSubmit.Size = new System.Drawing.Size(135, 34);
            this.btnERSubmit.TabIndex = 23;
            this.btnERSubmit.Text = "Submit";
            this.btnERSubmit.UseVisualStyleBackColor = true;
            this.btnERSubmit.Click += new System.EventHandler(this.btnERSubmit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(407, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 24);
            this.label2.TabIndex = 24;
            this.label2.Text = "Last Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(488, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(244, 25);
            this.label5.TabIndex = 25;
            this.label5.Text = "Employer Registration";
            // 
            // txtEFName
            // 
            this.txtEFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEFName.Location = new System.Drawing.Point(632, 126);
            this.txtEFName.Name = "txtEFName";
            this.txtEFName.Size = new System.Drawing.Size(172, 26);
            this.txtEFName.TabIndex = 1;
            // 
            // txtELNmae
            // 
            this.txtELNmae.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtELNmae.Location = new System.Drawing.Point(632, 181);
            this.txtELNmae.Name = "txtELNmae";
            this.txtELNmae.Size = new System.Drawing.Size(172, 26);
            this.txtELNmae.TabIndex = 2;
            // 
            // txtEEmailAdd
            // 
            this.txtEEmailAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEEmailAdd.Location = new System.Drawing.Point(632, 476);
            this.txtEEmailAdd.Name = "txtEEmailAdd";
            this.txtEEmailAdd.Size = new System.Drawing.Size(172, 26);
            this.txtEEmailAdd.TabIndex = 6;
            // 
            // txtEContactNo
            // 
            this.txtEContactNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEContactNo.Location = new System.Drawing.Point(632, 420);
            this.txtEContactNo.Name = "txtEContactNo";
            this.txtEContactNo.Size = new System.Drawing.Size(172, 26);
            this.txtEContactNo.TabIndex = 5;
            // 
            // txtEPassword
            // 
            this.txtEPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEPassword.Location = new System.Drawing.Point(632, 541);
            this.txtEPassword.Name = "txtEPassword";
            this.txtEPassword.Size = new System.Drawing.Size(172, 26);
            this.txtEPassword.TabIndex = 7;
            // 
            // txtEConfirmPass
            // 
            this.txtEConfirmPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEConfirmPass.Location = new System.Drawing.Point(632, 604);
            this.txtEConfirmPass.Name = "txtEConfirmPass";
            this.txtEConfirmPass.PasswordChar = '*';
            this.txtEConfirmPass.Size = new System.Drawing.Size(172, 26);
            this.txtEConfirmPass.TabIndex = 8;
            // 
            // txtECName
            // 
            this.txtECName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtECName.Location = new System.Drawing.Point(632, 245);
            this.txtECName.Name = "txtECName";
            this.txtECName.Size = new System.Drawing.Size(172, 26);
            this.txtECName.TabIndex = 3;
            // 
            // txtEdesignation
            // 
            this.txtEdesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEdesignation.Location = new System.Drawing.Point(632, 305);
            this.txtEdesignation.Name = "txtEdesignation";
            this.txtEdesignation.Size = new System.Drawing.Size(172, 26);
            this.txtEdesignation.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(409, 422);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 24);
            this.label10.TabIndex = 26;
            this.label10.Text = "Contact no";
            // 
            // txtELocation
            // 
            this.txtELocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtELocation.Location = new System.Drawing.Point(632, 367);
            this.txtELocation.Name = "txtELocation";
            this.txtELocation.Size = new System.Drawing.Size(172, 26);
            this.txtELocation.TabIndex = 27;
            // 
            // EmployerRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.txtELocation);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtEdesignation);
            this.Controls.Add(this.txtECName);
            this.Controls.Add(this.txtEConfirmPass);
            this.Controls.Add(this.txtEPassword);
            this.Controls.Add(this.txtEContactNo);
            this.Controls.Add(this.txtEEmailAdd);
            this.Controls.Add(this.txtELNmae);
            this.Controls.Add(this.txtEFName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnERSubmit);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "EmployerRegistration";
            this.Text = "EmployerRegistration";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmployerRegistration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnERSubmit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEFName;
        private System.Windows.Forms.TextBox txtELNmae;
        private System.Windows.Forms.TextBox txtEEmailAdd;
        private System.Windows.Forms.TextBox txtEContactNo;
        private System.Windows.Forms.TextBox txtEPassword;
        private System.Windows.Forms.TextBox txtEConfirmPass;
        private System.Windows.Forms.TextBox txtECName;
        private System.Windows.Forms.TextBox txtEdesignation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtELocation;
    }
}