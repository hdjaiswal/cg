﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class Employer : Form
    {
        public Employer()
        {
            InitializeComponent();
        }

        Validations validationsObj = new Validations();
        private void Employeer_Load(object sender, EventArgs e)
        {
            EmployeePanel.Visible = true;
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            //panel4.Visible = false;
        }


        private void LinklblPostNewJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            //panel4.Visible = false;
        }
        private void LinklblPostedJobs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
            DataTable jobTable = new DataTable();

            jobTable = validationsObj.GetPostedJobs(frmHomePage.Eempid);
            
            dgvpostedjobs.DataSource = jobTable;
        }

        private void LinklblJobAppliedByJS_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel3.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
        }
        private void EmployeePanel_Paint(object sender, PaintEventArgs e)
        {


        }
        private void btnClosePostedJobs_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void btnCloseJobAppliedByJS_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel3.Visible = false;
        }
        Validations validationObj = new Validations();
        private void btnSubmitJobs_Click(object sender, EventArgs e)
        {
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();

            try
            {
                ORSEntity jsObj = new ORSEntity();
            
                jsObj.DCompanyName = txtCName.Text;;
                jsObj.DPost = txtPost.Text;;
                jsObj.DVacancies = Convert.ToInt32(txtTVacancies.Text);
                jsObj.DPostedDate = Convert.ToDateTime(txtPDate.Text);
                jsObj.DLastDate = Convert.ToDateTime(txtLDate.Text);
                jsObj.DDescription = txtDescription.Text;
                jsObj.DPackage = Convert.ToDouble(txtPackage.Text);
                jsObj.DJobLocation = txtJLocation.Text;
                jsObj.DExperience = txtExpRequire.Text;
                jsObj.EmployeeID = Convert.ToInt32(label12.Text);
                

                validationObj.AddJobs(jsObj);
                MessageBox.Show("Job Posted Successfully");

            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        //private void linkLblUpdateDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    panel4.Visible = true;
        //    panel3.Visible = false;
        //    panel1.Visible = false;
        //    panel2.Visible = false;
        //}

        //private void btnUpdateDetails_Click(object sender, EventArgs e)
        //{
        //    panel4.Visible = false;
        //    MessageBox.Show("Details Updated Sucessfully");
        //    panel1.Visible = true;
        //}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void linkLblLogO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Are You sure want to Logout ", "Please Confirm", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }
    
        EmployerRegistration frmempreg = new EmployerRegistration();
        private void Employer_Activated(object sender, EventArgs e)
        {
            
            
            label2000.Text = frmHomePage.Euser;
            label12.Text = Convert.ToString(frmHomePage.Eempid);
        
             
        }

        private void panel1_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

      
        
    }
}
