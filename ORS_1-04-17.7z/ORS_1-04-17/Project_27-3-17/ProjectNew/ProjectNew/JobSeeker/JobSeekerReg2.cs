﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;
using System.Configuration;

namespace ProjectNew
{
    public partial class JobSeekerReg2 : Form
    {
        public JobSeekerReg2()
        {
            InitializeComponent();
        }

        Validations validationObj = new Validations();
        ORSEntity jsObj = new ORSEntity();

        private void btnJsReg2_Click(object sender, EventArgs e)
        {
            JobSeekerReg3 frm = new JobSeekerReg3();
            frm.Show();
            this.Hide();

            try
            {
             

                jsObj.PassingYr = Convert.ToInt32(txtPassingYr.Text);
                jsObj.Percentage = Convert.ToDouble(txtPercentage.Text);
                jsObj.UniversityName = txtUniversityName.Text;
             
                jsObj.Degree = comboBox1.Text;
                jsObj.Branch = txtJsBranch.Text;
              

                validationObj.AddJobSeekerQDetails(jsObj);

            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtPassyr_TextChanged(object sender, EventArgs e)
        {

        }
      

        private void JobSeekerReg2_Load(object sender, EventArgs e)
        {
           
          
        }
    }
}
