﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class JobSeeker: Form
    {
        public JobSeeker()
        {
            InitializeComponent();
        }

        ORSEntity jsObj = new ORSEntity();
        Validations validationObj=new Validations();

        private void JobSeeker_Load(object sender, EventArgs e)
        {
            JSPannel.Visible = true;
            label100.Visible = true;
           //label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            //btnPersonalDetail1.Visible = false;
           // btnQualificationDetail.Visible = false;
            btnAppliedDetail.Visible = false;
            btnSearchjob.Visible = false;
            //btnPDUpdate.Visible = false;
            btnQD1Update.Visible = false;
            panel2.Visible = false;
            panelAddMore1.Visible = false;
            panelAddMore2.Visible = false;

            
            //txtJsFName.Text = jsObj.JFirstName;
            //txtJsLName.Text = jsObj.JLastName;
            //txtJsMName.Text = jsObj.JMiddleName;
            //txtJsContactNo.Text = Convert.ToString(jsObj.JPhoneNo);
            //txtJsEmailAdd.Text = jsObj.JEmailAddress;
            //if (radioButton1.Checked)
            //{
            //    radioButton1.Text=jsObj.JGender;
            //}
            //else
            //{
            //     radioButton2.Text=jsObj.JGender;
            //}

            //if (radioButton3.Checked)
            //{
            //    radioButton3.Text=jsObj.JMaritalStatus;
            //}
            //else
            //{
            //    radioButton4.Text=jsObj.JMaritalStatus;
            //}

            //     txtJsPassword.Text=jsObj.JPassword;
             
            //    txtJsContactNo.Text=Convert.ToString(jsObj.JPhoneNo);
            //    txtJsAddress.Text=jsObj.JAddress;

            //    validationObj.VerifyJS();
               
           
        }

        private void PDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;
            label100.Visible = true;
            // btnPersonalDetail1.Visible = true;
            // btnPDUpdate.Visible = true;
            panel2.Visible = false;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            panelAddMore1.Visible = false;
        }

        private void QDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel2.Visible = true;
            //label2.Visible = true;
            btnQualificationDetail.Visible= true;
            btnQD1Update.Visible = true;
            panel1.Visible = false;
            //label100.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            panelAddMore1.Visible = false;
            panelAddMore2.Visible = false;
        }

        private void AppJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel3.Visible = true;
            label3.Visible = true;
            btnAppliedDetail.Visible = true;
            panel1.Visible = false;
           // label100.Visible = false;
            panel2.Visible = false;
            //label2.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            panelAddMore1.Visible = false;
        }

        private void SearchJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel4.Visible = true;
            label4.Visible = true;
            btnSearchjob.Visible = true;
            panel1.Visible = false;
           // label100.Visible = false;
            panel2.Visible = false;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            panelAddMore1.Visible = false;
        }

        private void btnSearchjob_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel1.Visible = true;
        }

        private void btnAppliedDetail_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel1.Visible = true;
        }

        private void btnQualificationDetail_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void btnPersonalDetail1_Click(object sender, EventArgs e)
        {
           // panel1.Visible = false;
        }

        private void btnPDUpdate_Click(object sender, EventArgs e)
        {
            //panel1.Visible = false;
            MessageBox.Show("Personal Details Updated Sucessfully");
        }

        private void btnQD1Update_Click(object sender, EventArgs e)
        {
           // panel2.Visible = false;
            MessageBox.Show("Qualification Details Updated Sucessfully");
        }

        //private void txtJsEmailAdd_TextChanged(object sender, EventArgs e)
        //{

        //}

        //private void label11_Click(object sender, EventArgs e)
        //{

        //}

        //private void panel1_Paint(object sender, PaintEventArgs e)
        //{

        //}

        //private void pnelAddMore_Paint(object sender, PaintEventArgs e)
        //{

        //}

        private void btnUpdateQD1_Click(object sender, EventArgs e)
        {
            panelAddMore1.Visible = true;
            panelAddMore2.Visible = false;
        }

        //private void label23_Click(object sender, EventArgs e)
        //{

        //}

        //private void btnQD2Update_Click(object sender, EventArgs e)
        //{
        //    MessageBox.Show("Details Updated Sucessfully");
        //    //panelAddMore1.Visible = false;
        //}

        private void linkLblLogO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Are you sure want to logout", "Please Confirm", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }

        private void JobSeeker_Activated(object sender, EventArgs e)
        {
            label1000.Text = frmHomePage.JSuser;
        }

        private void btnQD2Update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnSubmitSsc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnSubmitHsc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
        }

        private void btnUpdateQD2_Click(object sender, EventArgs e)
        {
            panelAddMore2.Visible = true;
        }

        private void label1000_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
