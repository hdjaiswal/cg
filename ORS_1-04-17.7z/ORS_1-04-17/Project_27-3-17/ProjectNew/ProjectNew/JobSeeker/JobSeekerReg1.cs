﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class JobSeekerReg1 : Form
    {
        public JobSeekerReg1()
        {
            InitializeComponent();
        }

        Validations validationObj = new Validations();
        private void btnJsReg1_Click(object sender, EventArgs e)
        {
            //JobSeekerReg1 frm1 = new JobSeekerReg1();
            JobSeekerReg2 frm = new JobSeekerReg2();
            frm.Visible = true;
            this.Hide();
            try
            {
                ORSEntity jsObj = new ORSEntity();

               jsObj.JFirstName = txtJsFName.Text;
               jsObj.JMiddleName = txtJsMName.Text;
               jsObj.JLastName = txtJsLName.Text;
               jsObj.JEmailAddress = txtJsEmailAdd.Text;
               jsObj.JDOB = Convert.ToDateTime(dateTimePicker1.Text);
               if (radioButton1.Checked)
               {
                   jsObj.JGender = radioButton1.Text;
               }
               else
               {
                   jsObj.JGender = radioButton2.Text;
               }

                if(radioButton3.Checked)
                {
                      jsObj.JMaritalStatus = radioButton3.Text;
                }
                else
                {
                    jsObj.JMaritalStatus=radioButton4.Text;
                }
               jsObj.JPassword = txtJsPassword.Text;
             
                jsObj.JPhoneNo= Convert.ToInt64(txtJsContactNo.Text);
                jsObj.JAddress = txtJsAddress.Text;

                validationObj.AddJobSeekerPDetails(jsObj);
             
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtJsConfirmPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void JobSeekerReg1_Load(object sender, EventArgs e)
        {

        }
    }
}
