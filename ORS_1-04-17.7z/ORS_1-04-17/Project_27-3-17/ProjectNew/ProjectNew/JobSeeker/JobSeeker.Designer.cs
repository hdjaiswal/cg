﻿namespace ProjectNew
{
    partial class JobSeeker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobSeeker));
            this.JSPannel = new System.Windows.Forms.Panel();
            this.PDetails = new System.Windows.Forms.LinkLabel();
            this.SearchJob = new System.Windows.Forms.LinkLabel();
            this.AppJob = new System.Windows.Forms.LinkLabel();
            this.QDetails = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtJsAddress = new System.Windows.Forms.TextBox();
            this.txtJsConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtJsPassword = new System.Windows.Forms.TextBox();
            this.txtJsEmailAdd = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtJsContactNo = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtJsLName = new System.Windows.Forms.TextBox();
            this.txtJsMName = new System.Windows.Forms.TextBox();
            this.txtJsFName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnPDUpdate = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelAddMore2 = new System.Windows.Forms.Panel();
            this.btnSubmitHsc = new System.Windows.Forms.Button();
            this.btnSubmitSsc = new System.Windows.Forms.Button();
            this.txtSscUniName = new System.Windows.Forms.TextBox();
            this.txtSscPassingYr = new System.Windows.Forms.TextBox();
            this.txtSscPercentage = new System.Windows.Forms.TextBox();
            this.txtHscUniName = new System.Windows.Forms.TextBox();
            this.txtHscPassingYr = new System.Windows.Forms.TextBox();
            this.txtHscPercentage = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnUpdateQD1 = new System.Windows.Forms.Button();
            this.txtUniversityName = new System.Windows.Forms.TextBox();
            this.panelAddMore1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btnUpdateQD2 = new System.Windows.Forms.Button();
            this.btnQD2Update = new System.Windows.Forms.Button();
            this.txtPercentage = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txtPassyr = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtUniName = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtBranch = new System.Windows.Forms.TextBox();
            this.txtPassingYr = new System.Windows.Forms.TextBox();
            this.txtJsPercentage = new System.Windows.Forms.TextBox();
            this.txtJsBranch = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnQD1Update = new System.Windows.Forms.Button();
            this.btnQualificationDetail = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnAppliedDetail = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSearchjob = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.jobsActive = new System.Windows.Forms.Label();
            this.linkLblLogO = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1000 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.JSPannel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelAddMore2.SuspendLayout();
            this.panelAddMore1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // JSPannel
            // 
            this.JSPannel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.JSPannel.Controls.Add(this.PDetails);
            this.JSPannel.Controls.Add(this.SearchJob);
            this.JSPannel.Controls.Add(this.AppJob);
            this.JSPannel.Controls.Add(this.QDetails);
            this.JSPannel.ForeColor = System.Drawing.Color.Transparent;
            this.JSPannel.Location = new System.Drawing.Point(12, 136);
            this.JSPannel.Name = "JSPannel";
            this.JSPannel.Size = new System.Drawing.Size(254, 579);
            this.JSPannel.TabIndex = 2;
            this.JSPannel.Visible = false;
            // 
            // PDetails
            // 
            this.PDetails.AutoSize = true;
            this.PDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PDetails.Location = new System.Drawing.Point(47, 52);
            this.PDetails.Name = "PDetails";
            this.PDetails.Size = new System.Drawing.Size(160, 24);
            this.PDetails.TabIndex = 0;
            this.PDetails.TabStop = true;
            this.PDetails.Text = "Personal Details";
            this.PDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.PDetails_LinkClicked);
            // 
            // SearchJob
            // 
            this.SearchJob.AutoSize = true;
            this.SearchJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchJob.Location = new System.Drawing.Point(47, 216);
            this.SearchJob.Name = "SearchJob";
            this.SearchJob.Size = new System.Drawing.Size(126, 24);
            this.SearchJob.TabIndex = 3;
            this.SearchJob.TabStop = true;
            this.SearchJob.Text = "Search Jobs";
            this.SearchJob.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SearchJob_LinkClicked);
            // 
            // AppJob
            // 
            this.AppJob.AutoSize = true;
            this.AppJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppJob.Location = new System.Drawing.Point(47, 162);
            this.AppJob.Name = "AppJob";
            this.AppJob.Size = new System.Drawing.Size(132, 24);
            this.AppJob.TabIndex = 2;
            this.AppJob.TabStop = true;
            this.AppJob.Text = "Applied Jobs";
            this.AppJob.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AppJob_LinkClicked);
            // 
            // QDetails
            // 
            this.QDetails.AutoSize = true;
            this.QDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QDetails.Location = new System.Drawing.Point(29, 107);
            this.QDetails.Name = "QDetails";
            this.QDetails.Size = new System.Drawing.Size(193, 24);
            this.QDetails.TabIndex = 1;
            this.QDetails.TabStop = true;
            this.QDetails.Text = "Qualification Details";
            this.QDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.QDetails_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtJsAddress);
            this.panel1.Controls.Add(this.txtJsConfirmPassword);
            this.panel1.Controls.Add(this.txtJsPassword);
            this.panel1.Controls.Add(this.txtJsEmailAdd);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtJsContactNo);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.txtJsLName);
            this.panel1.Controls.Add(this.txtJsMName);
            this.panel1.Controls.Add(this.txtJsFName);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label100);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.btnPDUpdate);
            this.panel1.Location = new System.Drawing.Point(307, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(824, 576);
            this.panel1.TabIndex = 4;
            // 
            // txtJsAddress
            // 
            this.txtJsAddress.Location = new System.Drawing.Point(588, 294);
            this.txtJsAddress.Multiline = true;
            this.txtJsAddress.Name = "txtJsAddress";
            this.txtJsAddress.Size = new System.Drawing.Size(190, 86);
            this.txtJsAddress.TabIndex = 63;
            // 
            // txtJsConfirmPassword
            // 
            this.txtJsConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsConfirmPassword.Location = new System.Drawing.Point(586, 233);
            this.txtJsConfirmPassword.Name = "txtJsConfirmPassword";
            this.txtJsConfirmPassword.PasswordChar = '*';
            this.txtJsConfirmPassword.Size = new System.Drawing.Size(190, 26);
            this.txtJsConfirmPassword.TabIndex = 62;
            // 
            // txtJsPassword
            // 
            this.txtJsPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPassword.Location = new System.Drawing.Point(588, 179);
            this.txtJsPassword.Name = "txtJsPassword";
            this.txtJsPassword.PasswordChar = '*';
            this.txtJsPassword.Size = new System.Drawing.Size(190, 26);
            this.txtJsPassword.TabIndex = 61;
            // 
            // txtJsEmailAdd
            // 
            this.txtJsEmailAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsEmailAdd.Location = new System.Drawing.Point(586, 119);
            this.txtJsEmailAdd.Name = "txtJsEmailAdd";
            this.txtJsEmailAdd.Size = new System.Drawing.Size(190, 26);
            this.txtJsEmailAdd.TabIndex = 60;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(437, 407);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(347, 40);
            this.groupBox2.TabIndex = 59;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Maritial Status";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(255, 0);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(92, 28);
            this.radioButton4.TabIndex = 1;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Married";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(149, 0);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(81, 28);
            this.radioButton3.TabIndex = 0;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Single";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(417, 287);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 24);
            this.label13.TabIndex = 58;
            this.label13.Text = "Address";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(407, 233);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(162, 24);
            this.label12.TabIndex = 57;
            this.label12.Text = "Confirm Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(407, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 24);
            this.label9.TabIndex = 56;
            this.label9.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(407, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(130, 24);
            this.label8.TabIndex = 55;
            this.label8.Text = "Email-address";
            // 
            // txtJsContactNo
            // 
            this.txtJsContactNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsContactNo.Location = new System.Drawing.Point(161, 344);
            this.txtJsContactNo.Name = "txtJsContactNo";
            this.txtJsContactNo.Size = new System.Drawing.Size(216, 26);
            this.txtJsContactNo.TabIndex = 54;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(161, 289);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(214, 22);
            this.dateTimePicker1.TabIndex = 53;
            // 
            // txtJsLName
            // 
            this.txtJsLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsLName.Location = new System.Drawing.Point(161, 235);
            this.txtJsLName.Name = "txtJsLName";
            this.txtJsLName.Size = new System.Drawing.Size(214, 26);
            this.txtJsLName.TabIndex = 52;
            // 
            // txtJsMName
            // 
            this.txtJsMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsMName.Location = new System.Drawing.Point(161, 179);
            this.txtJsMName.Name = "txtJsMName";
            this.txtJsMName.Size = new System.Drawing.Size(214, 26);
            this.txtJsMName.TabIndex = 51;
            // 
            // txtJsFName
            // 
            this.txtJsFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsFName.Location = new System.Drawing.Point(159, 121);
            this.txtJsFName.Name = "txtJsFName";
            this.txtJsFName.Size = new System.Drawing.Size(216, 26);
            this.txtJsFName.TabIndex = 50;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(32, 407);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(345, 40);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gender";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(228, 0);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(92, 28);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(131, 0);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(69, 28);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 24);
            this.label6.TabIndex = 48;
            this.label6.Text = "Contact No";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 24);
            this.label7.TabIndex = 47;
            this.label7.Text = "Date of Birth";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 24);
            this.label5.TabIndex = 46;
            this.label5.Text = "Last Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(26, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 24);
            this.label10.TabIndex = 45;
            this.label10.Text = "Middle Name";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.Transparent;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label100.Location = new System.Drawing.Point(26, 119);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(101, 24);
            this.label100.TabIndex = 44;
            this.label100.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(306, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(185, 25);
            this.label11.TabIndex = 43;
            this.label11.Text = "Personal Details";
            // 
            // btnPDUpdate
            // 
            this.btnPDUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPDUpdate.Location = new System.Drawing.Point(377, 494);
            this.btnPDUpdate.Name = "btnPDUpdate";
            this.btnPDUpdate.Size = new System.Drawing.Size(69, 29);
            this.btnPDUpdate.TabIndex = 2;
            this.btnPDUpdate.Text = "Update";
            this.btnPDUpdate.UseVisualStyleBackColor = true;
            this.btnPDUpdate.Click += new System.EventHandler(this.btnPDUpdate_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panelAddMore2);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.btnUpdateQD1);
            this.panel2.Controls.Add(this.txtUniversityName);
            this.panel2.Controls.Add(this.panelAddMore1);
            this.panel2.Controls.Add(this.txtPassingYr);
            this.panel2.Controls.Add(this.txtJsPercentage);
            this.panel2.Controls.Add(this.txtJsBranch);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnQD1Update);
            this.panel2.Controls.Add(this.btnQualificationDetail);
            this.panel2.Location = new System.Drawing.Point(307, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(824, 576);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panelAddMore2
            // 
            this.panelAddMore2.Controls.Add(this.btnSubmitHsc);
            this.panelAddMore2.Controls.Add(this.btnSubmitSsc);
            this.panelAddMore2.Controls.Add(this.txtSscUniName);
            this.panelAddMore2.Controls.Add(this.txtSscPassingYr);
            this.panelAddMore2.Controls.Add(this.txtSscPercentage);
            this.panelAddMore2.Controls.Add(this.txtHscUniName);
            this.panelAddMore2.Controls.Add(this.txtHscPassingYr);
            this.panelAddMore2.Controls.Add(this.txtHscPercentage);
            this.panelAddMore2.Controls.Add(this.label28);
            this.panelAddMore2.Controls.Add(this.label27);
            this.panelAddMore2.Controls.Add(this.label26);
            this.panelAddMore2.Controls.Add(this.label25);
            this.panelAddMore2.Controls.Add(this.label24);
            this.panelAddMore2.Location = new System.Drawing.Point(30, 378);
            this.panelAddMore2.Name = "panelAddMore2";
            this.panelAddMore2.Size = new System.Drawing.Size(778, 141);
            this.panelAddMore2.TabIndex = 45;
            // 
            // btnSubmitHsc
            // 
            this.btnSubmitHsc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitHsc.Location = new System.Drawing.Point(665, 45);
            this.btnSubmitHsc.Name = "btnSubmitHsc";
            this.btnSubmitHsc.Size = new System.Drawing.Size(75, 28);
            this.btnSubmitHsc.TabIndex = 51;
            this.btnSubmitHsc.Text = "Submit";
            this.btnSubmitHsc.UseVisualStyleBackColor = true;
            this.btnSubmitHsc.Click += new System.EventHandler(this.btnSubmitHsc_Click);
            // 
            // btnSubmitSsc
            // 
            this.btnSubmitSsc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitSsc.Location = new System.Drawing.Point(665, 86);
            this.btnSubmitSsc.Name = "btnSubmitSsc";
            this.btnSubmitSsc.Size = new System.Drawing.Size(75, 28);
            this.btnSubmitSsc.TabIndex = 50;
            this.btnSubmitSsc.Text = "Submit";
            this.btnSubmitSsc.UseVisualStyleBackColor = true;
            this.btnSubmitSsc.Click += new System.EventHandler(this.btnSubmitSsc_Click);
            // 
            // txtSscUniName
            // 
            this.txtSscUniName.Location = new System.Drawing.Point(450, 91);
            this.txtSscUniName.Name = "txtSscUniName";
            this.txtSscUniName.Size = new System.Drawing.Size(177, 20);
            this.txtSscUniName.TabIndex = 10;
            // 
            // txtSscPassingYr
            // 
            this.txtSscPassingYr.Location = new System.Drawing.Point(288, 94);
            this.txtSscPassingYr.Name = "txtSscPassingYr";
            this.txtSscPassingYr.Size = new System.Drawing.Size(100, 20);
            this.txtSscPassingYr.TabIndex = 9;
            // 
            // txtSscPercentage
            // 
            this.txtSscPercentage.Location = new System.Drawing.Point(116, 93);
            this.txtSscPercentage.Name = "txtSscPercentage";
            this.txtSscPercentage.Size = new System.Drawing.Size(100, 20);
            this.txtSscPercentage.TabIndex = 8;
            // 
            // txtHscUniName
            // 
            this.txtHscUniName.Location = new System.Drawing.Point(450, 49);
            this.txtHscUniName.Name = "txtHscUniName";
            this.txtHscUniName.Size = new System.Drawing.Size(177, 20);
            this.txtHscUniName.TabIndex = 7;
            // 
            // txtHscPassingYr
            // 
            this.txtHscPassingYr.Location = new System.Drawing.Point(290, 49);
            this.txtHscPassingYr.Name = "txtHscPassingYr";
            this.txtHscPassingYr.Size = new System.Drawing.Size(100, 20);
            this.txtHscPassingYr.TabIndex = 6;
            // 
            // txtHscPercentage
            // 
            this.txtHscPercentage.Location = new System.Drawing.Point(116, 49);
            this.txtHscPercentage.Name = "txtHscPercentage";
            this.txtHscPercentage.Size = new System.Drawing.Size(100, 20);
            this.txtHscPercentage.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(438, 10);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(201, 24);
            this.label28.TabIndex = 4;
            this.label28.Text = "University/Borad Name";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(117, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(107, 24);
            this.label27.TabIndex = 3;
            this.label27.Text = "Percentage";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(284, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(120, 24);
            this.label26.TabIndex = 2;
            this.label26.Text = "Passing Year";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(22, 89);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 24);
            this.label25.TabIndex = 1;
            this.label25.Text = "SSC";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(22, 45);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 24);
            this.label24.TabIndex = 0;
            this.label24.Text = "HSC";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "M.Tech",
            "M.E.",
            "M.Com",
            "M.A.",
            "M.C.A",
            "M.Sc"});
            this.comboBox1.Location = new System.Drawing.Point(211, 82);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(177, 21);
            this.comboBox1.TabIndex = 44;
            // 
            // btnUpdateQD1
            // 
            this.btnUpdateQD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateQD1.Location = new System.Drawing.Point(570, 179);
            this.btnUpdateQD1.Name = "btnUpdateQD1";
            this.btnUpdateQD1.Size = new System.Drawing.Size(150, 31);
            this.btnUpdateQD1.TabIndex = 43;
            this.btnUpdateQD1.Text = "Update More Details";
            this.btnUpdateQD1.UseVisualStyleBackColor = true;
            this.btnUpdateQD1.Click += new System.EventHandler(this.btnUpdateQD1_Click);
            // 
            // txtUniversityName
            // 
            this.txtUniversityName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUniversityName.Location = new System.Drawing.Point(211, 179);
            this.txtUniversityName.Name = "txtUniversityName";
            this.txtUniversityName.Size = new System.Drawing.Size(177, 26);
            this.txtUniversityName.TabIndex = 41;
            // 
            // panelAddMore1
            // 
            this.panelAddMore1.Controls.Add(this.comboBox2);
            this.panelAddMore1.Controls.Add(this.btnUpdateQD2);
            this.panelAddMore1.Controls.Add(this.btnQD2Update);
            this.panelAddMore1.Controls.Add(this.txtPercentage);
            this.panelAddMore1.Controls.Add(this.textBox5);
            this.panelAddMore1.Controls.Add(this.txtPassyr);
            this.panelAddMore1.Controls.Add(this.label21);
            this.panelAddMore1.Controls.Add(this.txtUniName);
            this.panelAddMore1.Controls.Add(this.label19);
            this.panelAddMore1.Controls.Add(this.label22);
            this.panelAddMore1.Controls.Add(this.label20);
            this.panelAddMore1.Controls.Add(this.label23);
            this.panelAddMore1.Controls.Add(this.txtBranch);
            this.panelAddMore1.Location = new System.Drawing.Point(30, 226);
            this.panelAddMore1.Name = "panelAddMore1";
            this.panelAddMore1.Size = new System.Drawing.Size(778, 144);
            this.panelAddMore1.TabIndex = 9;
            this.panelAddMore1.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "B.Tech",
            "B.E.",
            "B.Com",
            "B.A.",
            "B.C.A",
            "B.Sc"});
            this.comboBox2.Location = new System.Drawing.Point(181, 14);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(177, 21);
            this.comboBox2.TabIndex = 46;
            // 
            // btnUpdateQD2
            // 
            this.btnUpdateQD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateQD2.Location = new System.Drawing.Point(540, 103);
            this.btnUpdateQD2.Name = "btnUpdateQD2";
            this.btnUpdateQD2.Size = new System.Drawing.Size(150, 31);
            this.btnUpdateQD2.TabIndex = 50;
            this.btnUpdateQD2.Text = "Update More Details";
            this.btnUpdateQD2.UseVisualStyleBackColor = true;
            this.btnUpdateQD2.Click += new System.EventHandler(this.btnUpdateQD2_Click);
            // 
            // btnQD2Update
            // 
            this.btnQD2Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQD2Update.Location = new System.Drawing.Point(394, 101);
            this.btnQD2Update.Name = "btnQD2Update";
            this.btnQD2Update.Size = new System.Drawing.Size(75, 28);
            this.btnQD2Update.TabIndex = 49;
            this.btnQD2Update.Text = "Update";
            this.btnQD2Update.UseVisualStyleBackColor = true;
            this.btnQD2Update.Click += new System.EventHandler(this.btnQD2Update_Click);
            // 
            // txtPercentage
            // 
            this.txtPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPercentage.Location = new System.Drawing.Point(563, 64);
            this.txtPercentage.Name = "txtPercentage";
            this.txtPercentage.Size = new System.Drawing.Size(177, 26);
            this.txtPercentage.TabIndex = 48;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(-203, -169);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(177, 26);
            this.textBox5.TabIndex = 45;
            // 
            // txtPassyr
            // 
            this.txtPassyr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassyr.Location = new System.Drawing.Point(563, 25);
            this.txtPassyr.Name = "txtPassyr";
            this.txtPassyr.Size = new System.Drawing.Size(177, 26);
            this.txtPassyr.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(411, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(107, 24);
            this.label21.TabIndex = 30;
            this.label21.Text = "Percentage";
            // 
            // txtUniName
            // 
            this.txtUniName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUniName.Location = new System.Drawing.Point(181, 101);
            this.txtUniName.Name = "txtUniName";
            this.txtUniName.Size = new System.Drawing.Size(177, 26);
            this.txtUniName.TabIndex = 47;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(22, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 24);
            this.label19.TabIndex = 28;
            this.label19.Text = "Degree";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(411, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 24);
            this.label22.TabIndex = 32;
            this.label22.Text = "Passing Year";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(22, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 24);
            this.label20.TabIndex = 29;
            this.label20.Text = "Branch";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(20, 103);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(146, 24);
            this.label23.TabIndex = 33;
            this.label23.Text = "University Name";
            // 
            // txtBranch
            // 
            this.txtBranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranch.Location = new System.Drawing.Point(181, 64);
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.Size = new System.Drawing.Size(177, 26);
            this.txtBranch.TabIndex = 44;
            // 
            // txtPassingYr
            // 
            this.txtPassingYr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassingYr.Location = new System.Drawing.Point(570, 132);
            this.txtPassingYr.Name = "txtPassingYr";
            this.txtPassingYr.Size = new System.Drawing.Size(177, 26);
            this.txtPassingYr.TabIndex = 40;
            // 
            // txtJsPercentage
            // 
            this.txtJsPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPercentage.Location = new System.Drawing.Point(570, 75);
            this.txtJsPercentage.Name = "txtJsPercentage";
            this.txtJsPercentage.Size = new System.Drawing.Size(177, 26);
            this.txtJsPercentage.TabIndex = 39;
            // 
            // txtJsBranch
            // 
            this.txtJsBranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsBranch.Location = new System.Drawing.Point(211, 132);
            this.txtJsBranch.Name = "txtJsBranch";
            this.txtJsBranch.Size = new System.Drawing.Size(177, 26);
            this.txtJsBranch.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(44, 179);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(146, 24);
            this.label18.TabIndex = 32;
            this.label18.Text = "University Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(417, 134);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 24);
            this.label17.TabIndex = 31;
            this.label17.Text = "Passing Year";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(417, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 24);
            this.label16.TabIndex = 29;
            this.label16.Text = "Percentage";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(44, 134);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 24);
            this.label15.TabIndex = 28;
            this.label15.Text = "Branch";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(41, 82);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 24);
            this.label14.TabIndex = 27;
            this.label14.Text = "Degree";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(313, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 25);
            this.label1.TabIndex = 26;
            this.label1.Text = "Qualification Details";
            // 
            // btnQD1Update
            // 
            this.btnQD1Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQD1Update.Location = new System.Drawing.Point(424, 179);
            this.btnQD1Update.Name = "btnQD1Update";
            this.btnQD1Update.Size = new System.Drawing.Size(75, 31);
            this.btnQD1Update.TabIndex = 3;
            this.btnQD1Update.Text = "Update";
            this.btnQD1Update.UseVisualStyleBackColor = true;
            this.btnQD1Update.Click += new System.EventHandler(this.btnQD1Update_Click);
            // 
            // btnQualificationDetail
            // 
            this.btnQualificationDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQualificationDetail.Location = new System.Drawing.Point(359, 533);
            this.btnQualificationDetail.Name = "btnQualificationDetail";
            this.btnQualificationDetail.Size = new System.Drawing.Size(75, 31);
            this.btnQualificationDetail.TabIndex = 2;
            this.btnQualificationDetail.Text = "Close";
            this.btnQualificationDetail.UseVisualStyleBackColor = true;
            this.btnQualificationDetail.Click += new System.EventHandler(this.btnQualificationDetail_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnAppliedDetail);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(307, 136);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(824, 576);
            this.panel3.TabIndex = 7;
            // 
            // btnAppliedDetail
            // 
            this.btnAppliedDetail.Location = new System.Drawing.Point(611, 349);
            this.btnAppliedDetail.Name = "btnAppliedDetail";
            this.btnAppliedDetail.Size = new System.Drawing.Size(75, 23);
            this.btnAppliedDetail.TabIndex = 2;
            this.btnAppliedDetail.Text = "Close";
            this.btnAppliedDetail.UseVisualStyleBackColor = true;
            this.btnAppliedDetail.Click += new System.EventHandler(this.btnAppliedDetail_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(315, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Applied Jobs";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnSearchjob);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(29, 587);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(153, 100);
            this.panel4.TabIndex = 8;
            // 
            // btnSearchjob
            // 
            this.btnSearchjob.Location = new System.Drawing.Point(45, 61);
            this.btnSearchjob.Name = "btnSearchjob";
            this.btnSearchjob.Size = new System.Drawing.Size(75, 23);
            this.btnSearchjob.TabIndex = 2;
            this.btnSearchjob.Text = "Close";
            this.btnSearchjob.UseVisualStyleBackColor = true;
            this.btnSearchjob.Click += new System.EventHandler(this.btnSearchjob_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Search Jobs";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(118, 118);
            this.pictureBox3.TabIndex = 50;
            this.pictureBox3.TabStop = false;
            // 
            // jobsActive
            // 
            this.jobsActive.AutoSize = true;
            this.jobsActive.BackColor = System.Drawing.Color.Transparent;
            this.jobsActive.Font = new System.Drawing.Font("Century Schoolbook", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jobsActive.Location = new System.Drawing.Point(145, 12);
            this.jobsActive.Name = "jobsActive";
            this.jobsActive.Size = new System.Drawing.Size(613, 95);
            this.jobsActive.TabIndex = 11;
            this.jobsActive.Text = "jobactive.com";
            // 
            // linkLblLogO
            // 
            this.linkLblLogO.AutoSize = true;
            this.linkLblLogO.BackColor = System.Drawing.Color.Transparent;
            this.linkLblLogO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLblLogO.Location = new System.Drawing.Point(899, 106);
            this.linkLblLogO.Name = "linkLblLogO";
            this.linkLblLogO.Size = new System.Drawing.Size(77, 24);
            this.linkLblLogO.TabIndex = 44;
            this.linkLblLogO.TabStop = true;
            this.linkLblLogO.Text = "Log Out";
            this.linkLblLogO.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLblLogO_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(982, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 118);
            this.pictureBox1.TabIndex = 51;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(312, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 52;
            this.label2.Text = "Welcome";
            // 
            // label1000
            // 
            this.label1000.AutoSize = true;
            this.label1000.BackColor = System.Drawing.Color.Transparent;
            this.label1000.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1000.Location = new System.Drawing.Point(393, 110);
            this.label1000.Name = "label1000";
            this.label1000.Size = new System.Drawing.Size(78, 20);
            this.label1000.TabIndex = 53;
            this.label1000.Text = "label1000";
            this.label1000.Click += new System.EventHandler(this.label1000_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(826, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 54;
            this.pictureBox2.TabStop = false;
            // 
            // JobSeeker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1000);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.linkLblLogO);
            this.Controls.Add(this.jobsActive);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.JSPannel);
            this.Name = "JobSeeker";
            this.Text = "JobSeeker";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.JobSeeker_Activated);
            this.Load += new System.EventHandler(this.JobSeeker_Load);
            this.JSPannel.ResumeLayout(false);
            this.JSPannel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelAddMore2.ResumeLayout(false);
            this.panelAddMore2.PerformLayout();
            this.panelAddMore1.ResumeLayout(false);
            this.panelAddMore1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel JSPannel;
        internal System.Windows.Forms.LinkLabel PDetails;
        internal System.Windows.Forms.LinkLabel SearchJob;
        internal System.Windows.Forms.LinkLabel AppJob;
        internal System.Windows.Forms.LinkLabel QDetails;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAppliedDetail;
        private System.Windows.Forms.Button btnSearchjob;
        private System.Windows.Forms.Button btnPDUpdate;
        private System.Windows.Forms.Button btnQD1Update;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtJsAddress;
        private System.Windows.Forms.TextBox txtJsConfirmPassword;
        private System.Windows.Forms.TextBox txtJsPassword;
        private System.Windows.Forms.TextBox txtJsEmailAdd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtJsContactNo;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtJsLName;
        private System.Windows.Forms.TextBox txtJsMName;
        private System.Windows.Forms.TextBox txtJsFName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUniversityName;
        private System.Windows.Forms.TextBox txtPassingYr;
        private System.Windows.Forms.TextBox txtJsPercentage;
        private System.Windows.Forms.TextBox txtJsBranch;
        private System.Windows.Forms.Panel panelAddMore1;
        private System.Windows.Forms.Button btnUpdateQD1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtBranch;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox txtPassyr;
        private System.Windows.Forms.TextBox txtUniName;
        private System.Windows.Forms.Button btnQD2Update;
        private System.Windows.Forms.TextBox txtPercentage;
        private System.Windows.Forms.Button btnQualificationDetail;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label jobsActive;
        private System.Windows.Forms.LinkLabel linkLblLogO;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1000;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnUpdateQD2;
        private System.Windows.Forms.Panel panelAddMore2;
        private System.Windows.Forms.Button btnSubmitSsc;
        private System.Windows.Forms.TextBox txtSscUniName;
        private System.Windows.Forms.TextBox txtSscPassingYr;
        private System.Windows.Forms.TextBox txtSscPercentage;
        private System.Windows.Forms.TextBox txtHscUniName;
        private System.Windows.Forms.TextBox txtHscPassingYr;
        private System.Windows.Forms.TextBox txtHscPercentage;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button btnSubmitHsc;
    }
}

